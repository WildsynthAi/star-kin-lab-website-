import Link from "next/link";
import { ArrowRight, Quote } from "lucide-react";

export default function WhyLocalSection() {
  return (
    <section id="why-local" className="py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: content */}
          <div>
            <span className="section-label block mb-4">Founder's Perspective</span>
            <h2 className="heading-lg text-sk-white mb-6">
              Why Local Automation
              <br />
              <span className="text-sk-blue">Matters</span>
            </h2>

            <div className="relative pl-6 mb-8">
              <div className="absolute left-0 top-0 bottom-0 w-px bg-gradient-to-b from-sk-blue to-transparent" />
              <Quote size={20} className="text-sk-blue/40 mb-3" />
              <p className="text-sk-white text-xl leading-relaxed font-display font-300 italic">
                "Technology should be easy, useful and human friendly."
              </p>
            </div>

            <p className="text-sk-muted leading-relaxed mb-5">
              India has the engineering talent and manufacturing capacity to
              build its own automation ecosystem. Yet most organisations still
              depend on imported black-box systems that are expensive,
              difficult to maintain and impossible to customise for local
              operating conditions.
            </p>

            <p className="text-sk-muted leading-relaxed mb-8">
              STAR-KIN LABS was founded on the belief that a local automation
              ecosystem — one that builds, installs and supports technology
              for real-world Indian users — is not just possible, but
              necessary. When technology is designed close to its users, it
              works better, lasts longer and creates real value.
            </p>

            <Link href="/why-local-automation" className="btn-primary">
              Read Full Article <ArrowRight size={16} />
            </Link>
          </div>

          {/* Right: visual cards */}
          <div className="grid grid-cols-2 gap-4">
            {[
              {
                n: "01",
                title: "Local Context",
                desc: "Systems designed for Indian power, environment and operational realities.",
              },
              {
                n: "02",
                title: "Accessible Support",
                desc: "On-site maintenance and rapid support without international SLAs.",
              },
              {
                n: "03",
                title: "Cost Effective",
                desc: "Comparable capability at a fraction of imported system costs.",
              },
              {
                n: "04",
                title: "Customisable",
                desc: "Full access to source code, firmware and schematics — no lock-in.",
              },
            ].map((card) => (
              <div
                key={card.n}
                className="bg-sk-card border border-sk-border rounded-xl p-6 hover:border-sk-blue/30 transition-colors"
              >
                <div className="font-mono text-2xl font-bold text-sk-blue/20 mb-3">
                  {card.n}
                </div>
                <div className="font-display font-600 text-sk-white mb-2">
                  {card.title}
                </div>
                <p className="text-sk-muted text-sm leading-relaxed">
                  {card.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
