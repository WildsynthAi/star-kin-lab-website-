/**
 * LAB GALLERY SECTION
 * -------------------
 * Add real images to /public/assets/lab/
 * Recommended filenames:
 *   robotic-arm.jpg
 *   electronics-workstation.jpg
 *   3d-printing.jpg
 *   sensors.jpg
 *   control-systems.jpg
 *   embedded-dev.jpg
 *   prototype-assembly.jpg
 *   testing-rig.jpg
 */

const labImages = [
  {
    title: "Robotic Arm Development",
    file: "robotic-arm.jpg",
    size: "large",
  },
  {
    title: "Electronics Workstation",
    file: "electronics-workstation.jpg",
    size: "small",
  },
  {
    title: "3D Printing Lab",
    file: "3d-printing.jpg",
    size: "small",
  },
  {
    title: "Sensor Integration",
    file: "sensors.jpg",
    size: "small",
  },
  {
    title: "Control Systems",
    file: "control-systems.jpg",
    size: "medium",
  },
  {
    title: "Embedded Development",
    file: "embedded-dev.jpg",
    size: "medium",
  },
  {
    title: "Prototype Assembly",
    file: "prototype-assembly.jpg",
    size: "small",
  },
  {
    title: "Testing Rig",
    file: "testing-rig.jpg",
    size: "small",
  },
];

export default function LabSection() {
  return (
    <section id="lab" className="py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-12">
          <div>
            <span className="section-label block mb-3">
              Our Workspace
            </span>
            <h2 className="heading-lg text-sk-white">
              Inside the Lab
            </h2>
          </div>
          <p className="text-sk-muted max-w-md lg:text-right">
            Where intelligent systems are designed, assembled and tested before
            reaching the real world.
          </p>
        </div>

        {/* Gallery grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {labImages.map((img, i) => (
            <div
              key={img.file}
              className={`lab-card group ${
                img.size === "large"
                  ? "md:col-span-2 md:row-span-2"
                  : img.size === "medium"
                  ? "md:col-span-2"
                  : ""
              }`}
            >
              {/*
                Replace the placeholder div below with:
                <Image
                  src={`/assets/lab/${img.file}`}
                  alt={img.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
              */}
              <div className="absolute inset-0 bg-gradient-to-br from-sk-dark to-sk-card">
                <div className="absolute inset-0 bg-grid opacity-20" />
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                  <div className="w-16 h-16 rounded-xl bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center">
                    <span className="font-mono text-xs text-sk-blue">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                  </div>
                  <span className="font-mono text-[10px] text-sk-border text-center px-4">
                    {img.file}
                  </span>
                </div>
              </div>

              {/* Overlay */}
              <div className="lab-overlay">
                <span className="font-display font-500 text-sm text-sk-white">
                  {img.title}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Note for developer */}
        <div className="mt-6 p-4 border border-sk-border/50 rounded-lg bg-sk-card/30">
          <p className="font-mono text-xs text-sk-muted text-center">
            📁 Add lab images to{" "}
            <span className="text-sk-blue">/public/assets/lab/</span> with
            filenames listed above to populate this gallery.
          </p>
        </div>
      </div>
    </section>
  );
}
