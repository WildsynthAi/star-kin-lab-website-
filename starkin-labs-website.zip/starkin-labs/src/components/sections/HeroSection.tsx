import Link from "next/link";
import { ArrowRight, ChevronRight } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background layers */}
      <div className="absolute inset-0 bg-sk-black" />
      <div className="absolute inset-0 bg-grid opacity-100" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_-10%,rgba(26,111,255,0.18)_0%,transparent_60%)]" />

      {/* Subtle corner accents */}
      <div className="absolute top-24 left-12 w-px h-40 bg-gradient-to-b from-sk-blue/40 to-transparent" />
      <div className="absolute top-24 left-12 w-40 h-px bg-gradient-to-r from-sk-blue/40 to-transparent" />
      <div className="absolute top-24 right-12 w-px h-40 bg-gradient-to-b from-sk-blue/40 to-transparent" />
      <div className="absolute top-24 right-12 w-40 h-px bg-gradient-to-l from-sk-blue/40 to-transparent" />

      {/* Blue orb glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] rounded-full bg-[radial-gradient(ellipse,rgba(26,111,255,0.07)_0%,transparent_70%)] pointer-events-none" />

      <div className="relative z-10 max-w-5xl mx-auto px-6 lg:px-8 text-center pt-24 pb-16">
        {/* Status chip */}
        <div className="inline-flex items-center gap-2 mb-8">
          <div className="w-1.5 h-1.5 rounded-full bg-sk-blue animate-pulse" />
          <span className="section-label">
            AI · Robotics · Automation · Security
          </span>
        </div>

        {/* Logo mark */}
        <div className="flex justify-center mb-10">
          <div className="relative">
            {/*
              Replace this div with an <Image> component when logo is added:
              <Image src="/assets/logo/starkin-logo.png" alt="STAR-KIN LABS" width={160} height={80} className="object-contain" priority />
            */}
            <div className="w-40 h-20 rounded-xl bg-sk-card border border-sk-border flex items-center justify-center shadow-blue-md">
              <span className="font-display font-bold text-3xl text-sk-blue tracking-wider">
                SK
              </span>
            </div>
            <div className="absolute -inset-4 rounded-2xl bg-sk-blue/5 -z-10 blur-xl" />
          </div>
        </div>

        {/* Headline */}
        <h1 className="heading-xl text-sk-white mb-4">
          Building Intelligent
          <br />
          <span className="text-sk-blue">Environments</span>
        </h1>

        <p className="font-display font-300 text-xl text-sk-muted tracking-widest uppercase mb-6">
          Empowering the Real World
        </p>

        <p className="text-sk-muted text-lg max-w-2xl mx-auto leading-relaxed mb-12">
          STAR-KIN LABS develops AI-powered automation, robotics, cyber
          security, embedded systems and intelligent environment solutions
          designed for real-world deployment.
        </p>

        {/* CTA buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link href="/services" className="btn-primary text-base">
            View Services <ArrowRight size={16} />
          </Link>
          <Link href="/contact" className="btn-outline text-base">
            Contact Us <ChevronRight size={16} />
          </Link>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 pt-12 border-t border-sk-border">
          {[
            { n: "10+", label: "Service Areas" },
            { n: "5+", label: "Active Projects" },
            { n: "R&D", label: "Focus" },
            { n: "2026", label: "Incorporated" },
          ].map((s) => (
            <div key={s.label} className="text-center">
              <div className="stat-number">{s.n}</div>
              <div className="font-mono text-xs text-sk-muted tracking-widest uppercase mt-1">
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-sk-black to-transparent pointer-events-none" />
    </section>
  );
}
