import Link from "next/link";
import { ArrowRight, User } from "lucide-react";

export default function AboutSection() {
  return (
    <section id="about" className="py-24 bg-sk-dark/40">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-5 gap-12 items-start">
          {/* Company story: 3 cols */}
          <div className="lg:col-span-3">
            <span className="section-label block mb-4">Who We Are</span>
            <h2 className="heading-lg text-sk-white mb-6">
              About STAR-KIN LABS
            </h2>

            <p className="text-sk-muted leading-relaxed mb-5">
              STAR-KIN LABS (OPC) PRIVATE LIMITED was founded to bridge the gap
              between advanced technology and practical, real-world deployment.
              We are an engineering company focused on AI, robotics, automation,
              cyber security and embedded systems — built to solve real problems
              in real environments.
            </p>

            <p className="text-sk-muted leading-relaxed mb-5">
              We do not just prototype in isolation. Our focus is on systems
              that can be deployed, maintained and scaled — whether in a factory,
              a school lab, a retail store or a residential building.
            </p>

            <div className="grid grid-cols-2 gap-6 my-10 py-10 border-y border-sk-border">
              <div>
                <div className="font-display font-700 text-2xl text-sk-blue mb-1">
                  Mission
                </div>
                <p className="text-sk-muted text-sm leading-relaxed">
                  Build intelligent environments that improve efficiency,
                  security and usability for everyday users.
                </p>
              </div>
              <div>
                <div className="font-display font-700 text-2xl text-sk-blue mb-1">
                  Vision
                </div>
                <p className="text-sk-muted text-sm leading-relaxed">
                  Create technology systems that normal people can use
                  confidently — without complexity or dependence.
                </p>
              </div>
            </div>

            <Link href="/about" className="btn-outline">
              Full Company Profile <ArrowRight size={16} />
            </Link>
          </div>

          {/* Founder card: 2 cols */}
          <div className="lg:col-span-2">
            <div className="border border-sk-border rounded-2xl overflow-hidden bg-sk-card">
              {/* Founder photo */}
              <div className="aspect-[4/3] bg-gradient-to-br from-sk-dark to-sk-card relative overflow-hidden">
                {/*
                  Replace with:
                  <Image src="/assets/founder/founder.jpg" alt="Sandeep Singh" fill className="object-cover object-center" />
                */}
                <div className="absolute inset-0 bg-grid opacity-20" />
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                  <div className="w-20 h-20 rounded-full bg-sk-blue/10 border-2 border-sk-blue/20 flex items-center justify-center">
                    <User size={32} className="text-sk-blue/50" />
                  </div>
                  <span className="font-mono text-[10px] text-sk-border">
                    founder.jpg
                  </span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-sk-card to-transparent" />
              </div>

              {/* Founder info */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-display font-700 text-xl text-sk-white">
                      Sandeep Singh
                    </h3>
                    <p className="text-sk-blue text-sm font-display tracking-wide mt-0.5">
                      Founder & Director
                    </p>
                  </div>
                  <div className="w-8 h-8 rounded-lg bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center">
                    <span className="font-mono text-xs text-sk-blue">SS</span>
                  </div>
                </div>

                <p className="text-sk-muted text-sm leading-relaxed mb-5">
                  Hands-on engineering background with focus on automation,
                  intelligent systems and real-world deployment. Founded
                  STAR-KIN LABS to build technology that works for real users
                  in real environments.
                </p>

                <div className="pt-4 border-t border-sk-border">
                  <div className="flex flex-wrap gap-2">
                    {[
                      "Automation",
                      "Robotics",
                      "AI Systems",
                      "Embedded",
                    ].map((tag) => (
                      <span key={tag} className="sk-tag text-[10px]">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
