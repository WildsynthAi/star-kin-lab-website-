const industries = [
  {
    name: "Factories",
    desc: "Automation & monitoring for manufacturing lines",
    icon: "🏭",
    img: "/assets/industries/factory.jpg",
  },
  {
    name: "Workshops",
    desc: "Smart tooling and workflow automation",
    icon: "🔧",
    img: "/assets/industries/workshop.jpg",
  },
  {
    name: "Schools & Labs",
    desc: "Educational robotics and lab automation",
    icon: "🎓",
    img: "/assets/industries/education.jpg",
  },
  {
    name: "Agriculture",
    desc: "Smart sensors, irrigation and monitoring",
    icon: "🌾",
    img: "/assets/industries/agriculture.jpg",
  },
  {
    name: "Retail Stores",
    desc: "Security, automation and smart inventory",
    icon: "🏪",
    img: "/assets/industries/retail.jpg",
  },
  {
    name: "Offices",
    desc: "Building management and smart environments",
    icon: "🏢",
    img: "/assets/industries/office.jpg",
  },
  {
    name: "Warehouses",
    desc: "Logistics automation and safety systems",
    icon: "📦",
    img: "/assets/industries/warehouse.jpg",
  },
  {
    name: "Residential",
    desc: "Smart home, security and energy management",
    icon: "🏠",
    img: "/assets/industries/residential.jpg",
  },
];

export default function IndustriesSection() {
  return (
    <section id="industries" className="py-24 bg-sk-dark/50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="section-label block mb-3">Sectors We Serve</span>
          <h2 className="heading-lg text-sk-white mb-4">
            Industries We Work In
          </h2>
          <p className="text-sk-muted text-lg max-w-2xl mx-auto">
            Our systems are engineered for real operational environments — from
            factory floors to residential buildings.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {industries.map((ind) => (
            <div
              key={ind.name}
              className="group relative rounded-xl border border-sk-border bg-sk-card overflow-hidden cursor-default hover:border-sk-blue/40 transition-all duration-300 hover:-translate-y-1"
            >
              {/* Placeholder image area */}
              <div className="aspect-[4/3] bg-gradient-to-br from-sk-dark to-sk-card flex items-center justify-center relative overflow-hidden">
                {/*
                  Replace with:
                  <Image src={ind.img} alt={ind.name} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                */}
                <span className="text-5xl opacity-40 group-hover:opacity-60 transition-opacity">
                  {ind.icon}
                </span>
                <div className="absolute inset-0 bg-grid opacity-30" />

                {/* Placeholder notice - remove when images are added */}
                <div className="absolute bottom-2 right-2 text-[9px] font-mono text-sk-border opacity-0 group-hover:opacity-100 transition-opacity">
                  {ind.img.split("/").pop()}
                </div>
              </div>

              {/* Overlay gradient */}
              <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-sk-card to-transparent pointer-events-none" />

              {/* Content */}
              <div className="p-4">
                <div className="font-display font-600 text-sk-white mb-1">
                  {ind.name}
                </div>
                <p className="text-sk-muted text-xs leading-relaxed">{ind.desc}</p>
              </div>

              {/* Bottom line on hover */}
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-sk-blue to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
