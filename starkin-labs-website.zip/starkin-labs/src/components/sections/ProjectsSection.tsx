import Link from "next/link";
import { ArrowRight, ExternalLink } from "lucide-react";

const projects = [
  {
    id: "security-node",
    number: "01",
    title: "Autonomous Security Node",
    category: "AI · Security",
    description:
      "An intelligent edge-deployed security system using computer vision, motion analytics and real-time threat detection — designed for perimeter security without cloud dependency.",
    tags: ["Computer Vision", "Edge AI", "Embedded Linux"],
    status: "Active",
    img: "/assets/projects/security-node.jpg",
  },
  {
    id: "workbench",
    number: "02",
    title: "Intelligent Robotic Workbench",
    category: "Robotics · Automation",
    description:
      "A semi-autonomous workbench system integrating robotic arms, computer vision and smart tooling management to assist engineers in assembly and testing workflows.",
    tags: ["Robotic Arm", "Vision System", "HMI"],
    status: "Development",
    img: "/assets/projects/robotic-workbench.jpg",
  },
  {
    id: "environment-controller",
    number: "03",
    title: "Smart Environment Controller",
    category: "IoT · Embedded",
    description:
      "A unified controller for building environments — managing climate, lighting, access and energy consumption through a single embedded platform with mobile interface.",
    tags: ["RTOS", "IoT", "Mobile App"],
    status: "Prototype",
    img: "/assets/projects/environment-controller.jpg",
  },
  {
    id: "ai-monitoring",
    number: "04",
    title: "AI Monitoring Platform",
    category: "AI · Industrial",
    description:
      "Real-time machine health monitoring using sensor fusion and ML-based anomaly detection — predicts failures and reduces downtime in industrial environments.",
    tags: ["Sensor Fusion", "Anomaly Detection", "Dashboard"],
    status: "Active",
    img: "/assets/projects/ai-monitoring.jpg",
  },
  {
    id: "automation-dashboard",
    number: "05",
    title: "Industrial Automation Dashboard",
    category: "Automation · SCADA",
    description:
      "A comprehensive SCADA-style control dashboard for industrial automation lines — featuring live process monitoring, remote control and event logging.",
    tags: ["SCADA", "HMI", "Data Logging"],
    status: "Development",
    img: "/assets/projects/automation-dashboard.jpg",
  },
];

const statusColors: Record<string, string> = {
  Active: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  Development: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  Prototype: "bg-sky-500/10 text-sky-400 border-sky-500/20",
};

export default function ProjectsSection() {
  return (
    <section id="projects" className="py-24 bg-sk-dark/40">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="section-label block mb-3">Case Studies</span>
          <h2 className="heading-lg text-sk-white mb-4">Featured Projects</h2>
          <p className="text-sk-muted text-lg max-w-2xl mx-auto">
            Real-world engineering — systems we are building and deploying to
            solve practical problems.
          </p>
        </div>

        <div className="space-y-6">
          {projects.map((proj, i) => (
            <div
              key={proj.id}
              id={proj.id}
              className="project-card group"
            >
              <div className="flex flex-col lg:flex-row">
                {/* Image placeholder */}
                <div className="lg:w-80 aspect-video lg:aspect-auto lg:min-h-[200px] shrink-0 relative overflow-hidden bg-gradient-to-br from-sk-dark to-sk-card">
                  {/*
                    Replace with:
                    <Image src={proj.img} alt={proj.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                  */}
                  <div className="absolute inset-0 bg-grid opacity-20" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="font-display font-bold text-6xl text-sk-border/30 group-hover:text-sk-blue/20 transition-colors">
                      {proj.number}
                    </span>
                  </div>
                  <div className="absolute bottom-3 right-3 font-mono text-[9px] text-sk-border">
                    {proj.img.split("/").pop()}
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 p-8 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-3">
                      <span className="font-mono text-xs text-sk-blue">
                        {proj.number}
                      </span>
                      <span className="sk-tag">{proj.category}</span>
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono tracking-widest uppercase border ${statusColors[proj.status]}`}
                      >
                        <span className="w-1 h-1 rounded-full bg-current animate-pulse" />
                        {proj.status}
                      </span>
                    </div>

                    <h3 className="heading-md text-sk-white mb-3">
                      {proj.title}
                    </h3>
                    <p className="text-sk-muted leading-relaxed mb-5">
                      {proj.description}
                    </p>

                    <div className="flex flex-wrap gap-2">
                      {proj.tags.map((tag) => (
                        <span
                          key={tag}
                          className="font-mono text-[11px] text-sk-muted border border-sk-border px-3 py-1 rounded"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t border-sk-border flex items-center justify-between">
                    <Link
                      href={`/projects#${proj.id}`}
                      className="inline-flex items-center gap-2 text-sk-blue font-display text-sm font-500 hover:gap-3 transition-all"
                    >
                      View Case Study <ArrowRight size={14} />
                    </Link>
                    <ExternalLink size={14} className="text-sk-border" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/projects" className="btn-outline">
            View All Projects <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}
