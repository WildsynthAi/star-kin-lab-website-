import Link from "next/link";
import { ArrowRight, Calendar, Tag } from "lucide-react";

const posts = [
  {
    slug: "building-edge-ai-for-indian-factories",
    cat: "AI",
    catColor: "text-blue-400",
    date: "2026",
    title: "Building Edge AI for Indian Factories",
    excerpt:
      "Why deploying AI at the edge — without cloud dependency — is the right approach for manufacturing environments in India.",
  },
  {
    slug: "embedded-security-in-iot-systems",
    cat: "Cyber Security",
    catColor: "text-red-400",
    date: "2026",
    title: "Embedded Security in IoT Systems",
    excerpt:
      "Security cannot be an afterthought. How we approach threat modelling from the schematic stage in every IoT product we build.",
  },
  {
    slug: "robotics-in-small-workshops",
    cat: "Robotics",
    catColor: "text-emerald-400",
    date: "2026",
    title: "Robotics in Small Workshops",
    excerpt:
      "Industrial robots are not just for large factories. Practical robotic integration for small and medium-scale workshops.",
  },
];

export default function BlogPreviewSection() {
  return (
    <section id="blog" className="py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <span className="section-label block mb-3">Insights</span>
            <h2 className="heading-lg text-sk-white">From the Lab</h2>
          </div>
          <Link
            href="/blog"
            className="inline-flex items-center gap-2 text-sk-blue font-display text-sm font-500 hover:gap-3 transition-all"
          >
            View All Articles <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {posts.map((post) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              className="group block bg-sk-card border border-sk-border rounded-xl overflow-hidden hover:border-sk-blue/30 transition-all hover:-translate-y-1 duration-300"
            >
              {/* Image placeholder */}
              <div className="aspect-video bg-gradient-to-br from-sk-dark to-sk-card relative overflow-hidden">
                <div className="absolute inset-0 bg-grid opacity-20" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="font-mono text-[10px] text-sk-border">
                    /assets/blog/{post.slug}.jpg
                  </span>
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span
                    className={`inline-flex items-center gap-1 text-xs font-display font-500 ${post.catColor}`}
                  >
                    <Tag size={11} />
                    {post.cat}
                  </span>
                  <span className="text-sk-border">·</span>
                  <span className="text-sk-muted text-xs font-mono">
                    {post.date}
                  </span>
                </div>

                <h3 className="font-display font-600 text-sk-white text-lg mb-3 group-hover:text-sk-blue transition-colors leading-snug">
                  {post.title}
                </h3>

                <p className="text-sk-muted text-sm leading-relaxed">
                  {post.excerpt}
                </p>

                <div className="mt-4 inline-flex items-center gap-1 text-sk-blue text-xs font-display opacity-0 group-hover:opacity-100 transition-opacity">
                  Read Article <ArrowRight size={12} />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
