import Link from "next/link";
import {
  Brain,
  Cpu,
  Settings,
  Shield,
  Layers,
  Wifi,
  Home,
  FlaskConical,
  Activity,
  Code2,
  ArrowRight,
} from "lucide-react";

const services = [
  {
    id: "ai",
    icon: Brain,
    title: "AI Systems",
    description:
      "Machine learning models, computer vision, natural language processing and AI-powered decision engines built for real-world environments.",
    tags: ["ML Models", "Computer Vision", "NLP"],
  },
  {
    id: "robotics",
    icon: Cpu,
    title: "Robotics",
    description:
      "Autonomous robotic systems, robotic arms, navigation systems and custom robot development for industrial and research applications.",
    tags: ["Autonomous", "Industrial", "Research"],
  },
  {
    id: "automation",
    icon: Settings,
    title: "Automation Systems",
    description:
      "End-to-end process automation for factories, workshops and offices — including PLC integration, SCADA and workflow automation.",
    tags: ["PLC", "SCADA", "Workflow"],
  },
  {
    id: "security",
    icon: Shield,
    title: "Cyber Security",
    description:
      "Network security, penetration testing, intrusion detection systems and secure architecture design for industrial and enterprise environments.",
    tags: ["Network Security", "IDS", "Pen Testing"],
  },
  {
    id: "embedded",
    icon: Layers,
    title: "Embedded Systems",
    description:
      "Custom embedded hardware design, firmware development, microcontroller programming and real-time system integration.",
    tags: ["Firmware", "RTOS", "MCU"],
  },
  {
    id: "iot",
    icon: Wifi,
    title: "IoT Solutions",
    description:
      "Connected device ecosystems, sensor networks, edge computing and cloud-integrated IoT platforms for monitoring and control.",
    tags: ["Edge Computing", "Sensors", "Cloud IoT"],
  },
  {
    id: "smart",
    icon: Home,
    title: "Smart Home & Office",
    description:
      "Intelligent environment controllers, automated lighting, climate control, access systems and building management solutions.",
    tags: ["BMS", "Smart Lighting", "Access Control"],
  },
  {
    id: "prototype",
    icon: FlaskConical,
    title: "Prototype Development",
    description:
      "From concept to working prototype — rapid development using 3D printing, PCB design, sensor integration and iterative testing.",
    tags: ["PCB Design", "3D Printing", "Rapid Dev"],
  },
  {
    id: "industrial",
    icon: Activity,
    title: "Industrial Monitoring",
    description:
      "Real-time equipment health monitoring, predictive maintenance systems and data analytics dashboards for industrial operations.",
    tags: ["Predictive", "Real-time", "Analytics"],
  },
  {
    id: "rd",
    icon: Code2,
    title: "Custom R&D",
    description:
      "Collaborative research and development for academic institutions, startups and enterprises — from feasibility to functional systems.",
    tags: ["Research", "Feasibility", "Innovation"],
  },
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-24 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_40%_at_50%_50%,rgba(26,111,255,0.04)_0%,transparent_70%)]" />
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="section-label block mb-3">What We Build</span>
          <h2 className="heading-lg text-sk-white mb-4">
            Our Service Areas
          </h2>
          <p className="text-sk-muted text-lg max-w-2xl mx-auto">
            From AI research to physical deployment — we engineer systems that
            work in the real world, not just in the lab.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((svc) => (
            <div key={svc.id} id={svc.id} className="service-card group">
              {/* Icon */}
              <div className="w-12 h-12 rounded-lg bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center mb-6 group-hover:bg-sk-blue/20 transition-colors">
                <svc.icon size={22} className="text-sk-blue" />
              </div>

              <h3 className="font-display font-600 text-xl text-sk-white mb-3">
                {svc.title}
              </h3>
              <p className="text-sk-muted text-sm leading-relaxed mb-5">
                {svc.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-6">
                {svc.tags.map((tag) => (
                  <span key={tag} className="sk-tag">
                    {tag}
                  </span>
                ))}
              </div>

              <Link
                href={`/services#${svc.id}`}
                className="inline-flex items-center gap-1 text-sk-blue text-sm font-display font-500 tracking-wide hover:gap-2 transition-all"
              >
                Learn More <ArrowRight size={14} />
              </Link>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/services" className="btn-outline">
            View All Services <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}
