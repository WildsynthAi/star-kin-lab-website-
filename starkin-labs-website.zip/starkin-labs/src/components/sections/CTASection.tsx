import Link from "next/link";
import { ArrowRight, Mail } from "lucide-react";

export default function CTASection() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_50%,rgba(26,111,255,0.1)_0%,transparent_70%)]" />
      <div className="absolute inset-0 bg-grid opacity-50" />

      {/* Corner decorations */}
      <div className="absolute top-8 left-8 w-px h-16 bg-gradient-to-b from-sk-blue/40 to-transparent" />
      <div className="absolute top-8 left-8 w-16 h-px bg-gradient-to-r from-sk-blue/40 to-transparent" />
      <div className="absolute bottom-8 right-8 w-px h-16 bg-gradient-to-t from-sk-blue/40 to-transparent" />
      <div className="absolute bottom-8 right-8 w-16 h-px bg-gradient-to-l from-sk-blue/40 to-transparent" />

      <div className="max-w-3xl mx-auto px-6 lg:px-8 text-center relative z-10">
        <span className="section-label block mb-4">Get in Touch</span>
        <h2 className="heading-lg text-sk-white mb-5">
          Have a project in mind?
          <br />
          <span className="text-sk-blue">Let&apos;s engineer it together.</span>
        </h2>
        <p className="text-sk-muted text-lg mb-10">
          Whether you need a custom automation system, an AI solution or a
          prototype developed — we are ready to engage.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link href="/contact" className="btn-primary text-base">
            <Mail size={16} />
            Contact Us
          </Link>
          <Link href="/services" className="btn-outline text-base">
            Explore Services <ArrowRight size={16} />
          </Link>
        </div>

        <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-8 text-sm text-sk-muted">
          <a
            href="mailto:starkinlabs.official@gmail.com"
            className="hover:text-sk-blue-light transition-colors font-mono"
          >
            starkinlabs.official@gmail.com
          </a>
          <span className="hidden sm:block text-sk-border">|</span>
          <a
            href="tel:+916284358633"
            className="hover:text-sk-blue-light transition-colors font-mono"
          >
            +91 62843 58633
          </a>
        </div>
      </div>
    </section>
  );
}
