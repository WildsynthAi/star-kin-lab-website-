import Link from "next/link";
import { Mail, Phone, MapPin, Globe } from "lucide-react";

const footerCols = [
  {
    title: "Company",
    links: [
      { label: "About Us", href: "/about" },
      { label: "Founder", href: "/about#founder" },
      { label: "Careers", href: "/careers" },
      { label: "Contact", href: "/contact" },
    ],
  },
  {
    title: "Services",
    links: [
      { label: "AI Systems", href: "/services#ai" },
      { label: "Robotics", href: "/services#robotics" },
      { label: "Automation", href: "/services#automation" },
      { label: "Cyber Security", href: "/services#security" },
      { label: "IoT Solutions", href: "/services#iot" },
    ],
  },
  {
    title: "Projects",
    links: [
      { label: "Security Node", href: "/projects#security-node" },
      { label: "Robotic Workbench", href: "/projects#workbench" },
      {
        label: "Environment Controller",
        href: "/projects#environment-controller",
      },
      { label: "AI Monitoring", href: "/projects#ai-monitoring" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Blog", href: "/blog" },
      { label: "Research", href: "/blog#research" },
      { label: "Why Local Automation", href: "/why-local-automation" },
      { label: "FAQ", href: "/contact#faq" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Use", href: "/terms" },
      { label: "Disclaimer", href: "/disclaimer" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="bg-sk-dark border-t border-sk-border mt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 pt-16 pb-8">
        {/* Top grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-10 mb-16">
          {/* Brand column */}
          <div className="col-span-2 md:col-span-3 lg:col-span-1">
            <div className="font-display font-bold text-sk-white text-lg mb-1">
              STAR-KIN LABS
            </div>
            <div className="font-mono text-[10px] text-sk-blue tracking-widest mb-4">
              (OPC) PVT. LTD.
            </div>
            <p className="text-sk-muted text-sm leading-relaxed mb-5">
              Building Intelligent Environments. Empowering the Real World.
            </p>
            <div className="space-y-2">
              <a
                href="mailto:starkinlabs.official@gmail.com"
                className="flex items-center gap-2 text-sk-muted text-sm hover:text-sk-blue-light transition-colors"
              >
                <Mail size={13} />
                starkinlabs.official@gmail.com
              </a>
              <a
                href="tel:+916284358633"
                className="flex items-center gap-2 text-sk-muted text-sm hover:text-sk-blue-light transition-colors"
              >
                <Phone size={13} />
                +91 62843 58633
              </a>
              <a
                href="https://starkinlabs.com"
                className="flex items-center gap-2 text-sk-muted text-sm hover:text-sk-blue-light transition-colors"
              >
                <Globe size={13} />
                starkinlabs.com
              </a>
              <div className="flex items-start gap-2 text-sk-muted text-sm">
                <MapPin size={13} className="mt-0.5 shrink-0" />
                <span>
                  Annia Road, Amloh
                  <br />
                  Fatehgarh Sahib, Punjab
                  <br />
                  India — 147203
                </span>
              </div>
            </div>
          </div>

          {/* Link columns */}
          {footerCols.map((col) => (
            <div key={col.title}>
              <div className="font-display font-600 text-sk-white text-sm tracking-widest uppercase mb-4">
                {col.title}
              </div>
              <ul className="space-y-1">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link href={link.href} className="footer-link">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Company info bar */}
        <div className="border-t border-sk-border pt-8 mb-8">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <div className="font-display font-semibold text-sk-white text-sm mb-2">
                STAR-KIN LABS (OPC) PRIVATE LIMITED
              </div>
              <div className="grid grid-cols-2 gap-x-8 gap-y-1">
                <div>
                  <span className="font-mono text-[10px] text-sk-blue tracking-widest uppercase">
                    CIN
                  </span>
                  <p className="font-mono text-xs text-sk-muted mt-0.5">
                    U58201PB2026OPC068447
                  </p>
                </div>
                <div>
                  <span className="font-mono text-[10px] text-sk-blue tracking-widest uppercase">
                    GSTIN
                  </span>
                  <p className="font-mono text-xs text-sk-muted mt-0.5">
                    03ABTCS8388J1ZF
                  </p>
                </div>
              </div>
            </div>
            <div className="flex flex-col justify-end">
              <p className="text-sk-muted text-xs">
                Registered under the Companies Act, 2013. One Person Company
                incorporated in India.
              </p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-6 border-t border-sk-border">
          <p className="text-sk-muted text-sm">
            © {new Date().getFullYear()} STAR-KIN LABS (OPC) PRIVATE LIMITED.
            All Rights Reserved.
          </p>
          <div className="flex items-center gap-1">
            <span className="font-mono text-xs text-sk-border">
              starkinlabs.com
            </span>
            <span className="text-sk-border mx-2">·</span>
            <span className="text-sk-muted text-xs">Punjab, India</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
