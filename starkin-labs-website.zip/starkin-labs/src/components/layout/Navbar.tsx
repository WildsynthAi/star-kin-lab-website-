"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, X, ChevronDown } from "lucide-react";

const navLinks = [
  { label: "Home", href: "/" },
  {
    label: "Services",
    href: "/services",
    sub: [
      { label: "AI Systems", href: "/services#ai" },
      { label: "Robotics", href: "/services#robotics" },
      { label: "Automation", href: "/services#automation" },
      { label: "Cyber Security", href: "/services#security" },
      { label: "IoT Solutions", href: "/services#iot" },
    ],
  },
  { label: "Projects", href: "/projects" },
  { label: "Lab", href: "/#lab" },
  { label: "About", href: "/about" },
  { label: "Blog", href: "/blog" },
  { label: "Careers", href: "/careers" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-sk-black/95 backdrop-blur-md border-b border-sk-border shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-3 shrink-0">
              <div className="relative w-10 h-10">
                {/* Replace with actual logo */}
                <div className="w-10 h-10 rounded-lg bg-sk-card border border-sk-border flex items-center justify-center text-sk-blue font-display font-bold text-sm">
                  SK
                </div>
                {/* Uncomment when logo file is added:
                <Image
                  src="/assets/logo/starkin-logo.png"
                  alt="STAR-KIN LABS"
                  fill
                  className="object-contain"
                  priority
                />
                */}
              </div>
              <div>
                <div className="font-display font-bold text-sk-white text-base leading-none tracking-wide">
                  STAR-KIN LABS
                </div>
                <div className="font-mono text-[9px] text-sk-blue tracking-[0.15em] mt-0.5">
                  (OPC) PVT. LTD.
                </div>
              </div>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) =>
                link.sub ? (
                  <div
                    key={link.label}
                    className="relative"
                    onMouseEnter={() => setActiveDropdown(link.label)}
                    onMouseLeave={() => setActiveDropdown(null)}
                  >
                    <button className="nav-link flex items-center gap-1 px-3 py-2">
                      {link.label}
                      <ChevronDown size={12} />
                    </button>
                    {activeDropdown === link.label && (
                      <div className="absolute top-full left-0 mt-2 w-48 bg-sk-dark border border-sk-border rounded-lg shadow-[0_8px_32px_rgba(0,0,0,0.6)] py-1 z-50">
                        {link.sub.map((sub) => (
                          <Link
                            key={sub.label}
                            href={sub.href}
                            className="block px-4 py-2 text-sm text-sk-muted hover:text-sk-white hover:bg-sk-card transition-colors font-body"
                          >
                            {sub.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    key={link.label}
                    href={link.href}
                    className="nav-link px-3 py-2"
                  >
                    {link.label}
                  </Link>
                )
              )}
            </div>

            {/* CTA */}
            <div className="hidden lg:flex items-center gap-3">
              <Link href="/contact" className="btn-primary text-sm py-2 px-5">
                Contact Us
              </Link>
            </div>

            {/* Mobile Toggle */}
            <button
              className="lg:hidden text-sk-muted hover:text-sk-white transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile Nav */}
      <div className={`mobile-nav lg:hidden ${mobileOpen ? "open" : ""}`}>
        <div className="flex flex-col gap-1">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="font-display font-500 text-sk-muted hover:text-sk-white transition-colors py-3 px-2 text-lg border-b border-sk-border/30"
              onClick={() => setMobileOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/contact"
            className="btn-primary mt-6 justify-center"
            onClick={() => setMobileOpen(false)}
          >
            Contact Us
          </Link>
        </div>
      </div>
    </>
  );
}
