import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms of Use",
  description: "Terms of Use for starkinlabs.com — STAR-KIN LABS (OPC) PRIVATE LIMITED.",
};

export default function TermsPage() {
  return (
    <>
      <section className="pt-32 pb-12 relative">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="max-w-3xl mx-auto px-6 lg:px-8 relative z-10">
          <span className="section-label block mb-4">Legal</span>
          <h1 className="heading-xl text-sk-white mb-4">Terms of Use</h1>
          <p className="text-sk-muted">
            Last updated: 2026 — STAR-KIN LABS (OPC) PRIVATE LIMITED
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 space-y-10 text-sk-muted leading-relaxed">
          {[
            {
              title: "1. Acceptance of Terms",
              body: "By accessing and using starkinlabs.com, you accept and agree to be bound by these Terms of Use. If you do not agree to these terms, please do not use this website.",
            },
            {
              title: "2. Intellectual Property",
              body: "All content on this website — including text, images, logos, designs and technical documentation — is the property of STAR-KIN LABS (OPC) PRIVATE LIMITED and is protected by applicable intellectual property laws. Reproduction without prior written permission is prohibited.",
            },
            {
              title: "3. Use of Website",
              body: "You may use this website for lawful purposes only. You must not use it in any way that violates applicable laws, infringes the rights of others or interferes with the operation of the website.",
            },
            {
              title: "4. Accuracy of Information",
              body: "We strive to keep information on this website accurate and up to date. However, we make no warranties about the completeness, accuracy or reliability of any content. Technical specifications and availability of services are subject to change.",
            },
            {
              title: "5. Limitation of Liability",
              body: "STAR-KIN LABS (OPC) PRIVATE LIMITED shall not be liable for any direct, indirect, incidental or consequential damages arising from your use of this website or reliance on its content.",
            },
            {
              title: "6. Governing Law",
              body: "These terms are governed by the laws of India. Any disputes shall be subject to the exclusive jurisdiction of the courts of Fatehgarh Sahib, Punjab, India.",
            },
            {
              title: "7. Changes to Terms",
              body: "We reserve the right to update these terms at any time. Continued use of the website after changes constitutes acceptance of the revised terms.",
            },
            {
              title: "8. Contact",
              body: "For questions regarding these terms, contact us at starkinlabs.official@gmail.com.",
            },
          ].map((section) => (
            <div key={section.title}>
              <h2 className="font-display font-600 text-xl text-sk-white mb-3">
                {section.title}
              </h2>
              <p>{section.body}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
