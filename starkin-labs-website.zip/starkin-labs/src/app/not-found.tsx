import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <section className="min-h-screen flex items-center justify-center relative">
      <div className="absolute inset-0 bg-grid opacity-40" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_50%,rgba(26,111,255,0.08)_0%,transparent_70%)]" />
      <div className="relative z-10 text-center px-6">
        <div className="font-mono text-[8rem] font-bold text-sk-border leading-none mb-6">
          404
        </div>
        <h1 className="font-display font-700 text-3xl text-sk-white mb-4">
          Page Not Found
        </h1>
        <p className="text-sk-muted text-lg max-w-md mx-auto mb-10">
          The page you are looking for does not exist or has been moved.
        </p>
        <Link href="/" className="btn-primary inline-flex">
          <ArrowLeft size={16} /> Back to Home
        </Link>
      </div>
    </section>
  );
}
