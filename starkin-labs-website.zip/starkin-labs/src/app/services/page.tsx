import type { Metadata } from "next";
import Link from "next/link";
import {
  Brain, Cpu, Settings, Shield, Layers, Wifi,
  Home, FlaskConical, Activity, Code2, ArrowRight, CheckCircle2
} from "lucide-react";

export const metadata: Metadata = {
  title: "Services",
  description:
    "Explore STAR-KIN LABS service offerings: AI systems, robotics, automation, cyber security, embedded systems, IoT and smart environment solutions.",
};

const services = [
  {
    id: "ai",
    icon: Brain,
    title: "AI Systems",
    tagline: "Intelligence at the Edge",
    description:
      "We develop machine learning models, computer vision pipelines and AI inference engines that run on real hardware — in factories, security systems and field devices — without cloud dependency.",
    capabilities: [
      "Custom ML model training and deployment",
      "Computer vision for object detection and tracking",
      "Natural language processing and voice interfaces",
      "Edge AI on embedded hardware (NVIDIA Jetson, RPi, custom MCUs)",
      "AI-powered decision and alert systems",
    ],
  },
  {
    id: "robotics",
    icon: Cpu,
    title: "Robotics",
    tagline: "Autonomous Systems for Real Work",
    description:
      "From robotic arms to autonomous mobile robots — we design, build and program robotic systems for industrial, research and educational applications.",
    capabilities: [
      "Robotic arm design and control systems",
      "Autonomous mobile robot (AMR) development",
      "ROS-based robot programming",
      "Vision-guided robotic pick-and-place",
      "Custom end-effectors and tooling",
    ],
  },
  {
    id: "automation",
    icon: Settings,
    title: "Automation Systems",
    tagline: "Smarter Processes, Less Manual Work",
    description:
      "End-to-end process automation covering PLC programming, SCADA integration, conveyor control, sorting systems and full workflow automation for manufacturing and logistics environments.",
    capabilities: [
      "PLC and ladder logic programming",
      "SCADA system development",
      "HMI design and implementation",
      "Conveyor and material handling automation",
      "Process data logging and analytics",
    ],
  },
  {
    id: "security",
    icon: Shield,
    title: "Cyber Security",
    tagline: "Security from the Ground Up",
    description:
      "We approach security at the hardware level — designing secure embedded architectures, conducting penetration testing and implementing intrusion detection for industrial and enterprise networks.",
    capabilities: [
      "Network security architecture and hardening",
      "Industrial control system (ICS/OT) security",
      "Penetration testing and vulnerability assessment",
      "Intrusion detection and monitoring systems",
      "Secure firmware and boot design",
    ],
  },
  {
    id: "embedded",
    icon: Layers,
    title: "Embedded Systems",
    tagline: "Hardware That Thinks",
    description:
      "Custom embedded hardware and firmware — from schematic to PCB to production firmware — designed for reliability in harsh environments.",
    capabilities: [
      "Schematic design and PCB layout",
      "Firmware development in C/C++ and Rust",
      "RTOS integration (FreeRTOS, Zephyr)",
      "Microcontroller selection and peripheral design",
      "Hardware debugging, testing and certification prep",
    ],
  },
  {
    id: "iot",
    icon: Wifi,
    title: "IoT Solutions",
    tagline: "Connected. Monitored. Controlled.",
    description:
      "Complete IoT ecosystems from sensor hardware to cloud dashboards — device communication, edge processing, data pipelines and control interfaces.",
    capabilities: [
      "Sensor selection, integration and calibration",
      "MQTT, LoRaWAN, Zigbee and Wi-Fi connectivity",
      "Edge processing and local intelligence",
      "Cloud platform integration and dashboards",
      "Remote monitoring and OTA firmware updates",
    ],
  },
  {
    id: "smart",
    icon: Home,
    title: "Smart Home & Office Automation",
    tagline: "Environments That Respond",
    description:
      "Integrated building management — smart lighting, climate control, access systems, energy monitoring and security in a single, user-friendly platform.",
    capabilities: [
      "Automated lighting and climate control",
      "Smart access and visitor management",
      "Energy monitoring and optimisation",
      "Voice and app-based control interfaces",
      "Integration with KNX, Modbus and custom protocols",
    ],
  },
  {
    id: "prototype",
    icon: FlaskConical,
    title: "Prototype Development",
    tagline: "Concept to Working Device",
    description:
      "Rapid prototyping for startups, research institutions and enterprises — from PCB design and 3D printing to firmware and field testing.",
    capabilities: [
      "Concept feasibility analysis",
      "3D printing and mechanical design",
      "PCB design and assembly",
      "Firmware and software development",
      "Field testing and iteration",
    ],
  },
  {
    id: "industrial",
    icon: Activity,
    title: "Industrial Monitoring",
    tagline: "Know Before It Fails",
    description:
      "Real-time condition monitoring using vibration, temperature, current and acoustic sensors — with ML-based anomaly detection to predict failures before they occur.",
    capabilities: [
      "Multi-sensor data acquisition systems",
      "Real-time machine health dashboards",
      "ML-based anomaly detection",
      "Predictive maintenance scheduling",
      "Historian and data export integration",
    ],
  },
  {
    id: "rd",
    icon: Code2,
    title: "Custom R&D",
    tagline: "From Research to Reality",
    description:
      "We collaborate on research projects requiring engineering depth — from academic institutions to early-stage companies — with an emphasis on producing working systems, not just papers.",
    capabilities: [
      "Technology feasibility studies",
      "Academic and industry research partnerships",
      "Proof-of-concept development",
      "IP documentation and patent support",
      "Transition from research to production",
    ],
  },
];

export default function ServicesPage() {
  return (
    <>
      {/* Page header */}
      <section className="pt-32 pb-16 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(26,111,255,0.12)_0%,transparent_60%)]" />
        <div className="absolute inset-0 bg-grid opacity-50" />
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center relative z-10">
          <span className="section-label block mb-4">What We Build</span>
          <h1 className="heading-xl text-sk-white mb-5">Our Services</h1>
          <p className="text-sk-muted text-xl max-w-2xl mx-auto leading-relaxed">
            From AI inference to physical robotics — complete engineering
            capability for intelligent system development and deployment.
          </p>
        </div>
      </section>

      {/* Services detail */}
      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 space-y-8">
          {services.map((svc) => (
            <div
              key={svc.id}
              id={svc.id}
              className="bg-sk-card border border-sk-border rounded-2xl p-8 lg:p-10 hover:border-sk-blue/25 transition-colors"
            >
              <div className="grid lg:grid-cols-3 gap-10">
                <div className="lg:col-span-2">
                  <div className="flex items-start gap-5 mb-6">
                    <div className="w-14 h-14 rounded-xl bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center shrink-0">
                      <svc.icon size={26} className="text-sk-blue" />
                    </div>
                    <div>
                      <h2 className="font-display font-700 text-2xl text-sk-white">
                        {svc.title}
                      </h2>
                      <p className="text-sk-blue font-display text-sm tracking-wide mt-0.5">
                        {svc.tagline}
                      </p>
                    </div>
                  </div>
                  <p className="text-sk-muted leading-relaxed">
                    {svc.description}
                  </p>
                </div>

                <div>
                  <div className="font-display font-500 text-sm text-sk-white mb-4 tracking-wide uppercase">
                    Capabilities
                  </div>
                  <ul className="space-y-3">
                    {svc.capabilities.map((cap) => (
                      <li key={cap} className="flex items-start gap-3">
                        <CheckCircle2
                          size={14}
                          className="text-sk-blue mt-0.5 shrink-0"
                        />
                        <span className="text-sk-muted text-sm">{cap}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 border-t border-sk-border">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="heading-md text-sk-white mb-4">
            Need a custom solution?
          </h2>
          <p className="text-sk-muted mb-8">
            Tell us about your project and we will advise on the right approach.
          </p>
          <Link href="/contact" className="btn-primary">
            Start a Conversation <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
