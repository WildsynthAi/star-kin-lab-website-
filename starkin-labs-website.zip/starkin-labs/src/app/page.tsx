import type { Metadata } from "next";
import HeroSection from "@/components/sections/HeroSection";
import ServicesSection from "@/components/sections/ServicesSection";
import IndustriesSection from "@/components/sections/IndustriesSection";
import LabSection from "@/components/sections/LabSection";
import ProjectsSection from "@/components/sections/ProjectsSection";
import WhyLocalSection from "@/components/sections/WhyLocalSection";
import AboutSection from "@/components/sections/AboutSection";
import BlogPreviewSection from "@/components/sections/BlogPreviewSection";
import CTASection from "@/components/sections/CTASection";

export const metadata: Metadata = {
  title: "STAR-KIN LABS — Building Intelligent Environments",
  description:
    "AI-powered automation, robotics, cyber security, embedded systems and intelligent environment solutions for real-world deployment. Based in Punjab, India.",
};

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <ServicesSection />
      <IndustriesSection />
      <LabSection />
      <ProjectsSection />
      <WhyLocalSection />
      <AboutSection />
      <BlogPreviewSection />
      <CTASection />
    </>
  );
}
