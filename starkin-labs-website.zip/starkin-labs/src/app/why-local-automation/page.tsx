import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Why Local Automation Matters",
  description:
    "A founder's perspective on why India needs its own automation ecosystem — technology that is built, installed and supported locally for real-world users.",
};

export default function WhyLocalAutomationPage() {
  return (
    <>
      <section className="pt-32 pb-12 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(26,111,255,0.1)_0%,transparent_60%)]" />
        <div className="absolute inset-0 bg-grid opacity-40" />
        <div className="max-w-3xl mx-auto px-6 lg:px-8 relative z-10">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sk-muted text-sm mb-8 hover:text-sk-white transition-colors"
          >
            <ArrowLeft size={14} /> Back to Home
          </Link>
          <span className="section-label block mb-4">Founder's Perspective</span>
          <h1 className="heading-xl text-sk-white mb-5">
            Why Local Automation Matters
          </h1>
          <p className="text-sk-muted text-lg">
            An essay on building technology for real users — written from the
            engineering floor, not the boardroom.
          </p>
          <div className="mt-6 flex items-center gap-4 pt-6 border-t border-sk-border">
            <div>
              <div className="font-display font-600 text-sk-white text-sm">
                Sandeep Singh
              </div>
              <div className="text-sk-muted text-xs">
                Founder & Director, STAR-KIN LABS
              </div>
            </div>
          </div>
        </div>
      </section>

      <article className="pb-24">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 prose prose-invert prose-lg">
          <div className="space-y-8 text-sk-muted leading-relaxed">
            <p className="text-xl text-sk-white leading-relaxed font-display font-300">
              Technology should be easy, useful and human friendly. That sounds
              obvious — but in practice, most technology deployed in Indian
              industrial and commercial environments is none of these things.
            </p>

            <h2 className="font-display font-700 text-2xl text-sk-white not-prose">
              The Problem
            </h2>
            <p>
              Walk into most factories, workshops or commercial buildings across
              India and you will find one of two situations. Either the facility
              has no automation at all — running on manual processes that are
              slow, inconsistent and error-prone. Or it has imported automation
              systems that were expensive to install, are difficult to maintain
              and rely entirely on foreign technical support that costs more per
              visit than the monthly salary of the engineer operating the
              machine.
            </p>
            <p>
              This is not a technology problem. The technology to automate
              these environments exists and is increasingly affordable.
              It is a deployment and support problem. Systems designed for
              German factories or American warehouses are not designed for
              Indian power fluctuations, Indian dust levels, Indian heat or
              Indian maintenance teams.
            </p>

            <h2 className="font-display font-700 text-2xl text-sk-white not-prose">
              What &apos;Local&apos; Actually Means
            </h2>
            <p>
              When I say local automation, I do not mean low-quality automation.
              I mean automation that is:
            </p>
            <ul className="space-y-3 not-prose">
              {[
                "Designed with Indian operating conditions in mind — power quality, ambient temperature, humidity, dust",
                "Installed by engineers who can be physically present for commissioning, calibration and troubleshooting",
                "Maintained locally, with spare parts that are accessible and firmware that can be updated without international support tickets",
                "Priced for the actual economic reality of Indian SMEs and mid-scale manufacturers",
                "Documented and operated in a way that does not require a foreign specialist to understand",
              ].map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <span className="text-sk-blue mt-1 shrink-0">→</span>
                  <span className="text-sk-muted">{item}</span>
                </li>
              ))}
            </ul>

            <h2 className="font-display font-700 text-2xl text-sk-white not-prose">
              The Opportunity
            </h2>
            <p>
              India manufactures at scale across textiles, automotive, food
              processing, chemicals, electronics and dozens of other sectors.
              The overwhelming majority of this manufacturing is done by
              small and medium enterprises — facilities with 10 to 500
              workers — that have never been the target market for traditional
              industrial automation vendors.
            </p>
            <p>
              These are exactly the environments that stand to gain the most
              from intelligent automation. Not because they need to replace
              workers, but because they need to make their workers more
              effective, their processes more consistent and their facilities
              safer and more efficient.
            </p>
            <p>
              The economics are now in their favour. Embedded hardware has
              become cheap. Open-source software stacks — from FreeRTOS to
              TensorFlow Lite — bring industrial-grade capability to
              small-scale deployments. AI that once required expensive GPU
              clusters now runs on a Raspberry Pi.
            </p>
            <p>
              The missing piece is not the technology. It is the engineering
              company willing to actually go to these facilities, understand
              the specific problem, design a solution that works in that
              environment and stand behind it after installation.
            </p>

            <h2 className="font-display font-700 text-2xl text-sk-white not-prose">
              What We Are Building
            </h2>
            <p>
              STAR-KIN LABS was founded to be that company. We work across AI,
              robotics, embedded systems and automation — but our focus is
              always on real-world deployment, not research for its own sake.
            </p>
            <p>
              Every system we design is designed to be used by real people in
              real environments. That means simple interfaces, reliable
              hardware, maintainable firmware and honest engineering — systems
              that operators can understand and that do not require constant
              specialist intervention to keep running.
            </p>
            <p>
              We believe that India does not need to wait for multinationals
              to eventually notice the SME market. We can build that ecosystem
              ourselves, starting from the factory floor up.
            </p>

            <blockquote className="not-prose border-l-2 border-sk-blue pl-6 my-8">
              <p className="text-xl text-sk-white font-display font-300 italic">
                &ldquo;Technology that cannot be maintained locally will
                eventually be abandoned locally. Build it right from the start.&rdquo;
              </p>
              <cite className="block mt-3 text-sk-muted text-sm not-italic">
                — Sandeep Singh, Founder, STAR-KIN LABS
              </cite>
            </blockquote>

            <h2 className="font-display font-700 text-2xl text-sk-white not-prose">
              A Call to Engineers
            </h2>
            <p>
              If you are an engineer in India — whether in a university, a
              startup or already in industry — the opportunity to build the
              local automation ecosystem is real and it is now. The tools are
              available. The demand is there. What is needed is the
              willingness to work in the real world, to get your hands dirty
              and to build things that actually work.
            </p>
            <p>
              That is what we are here to do. And we are just getting started.
            </p>
          </div>

          <div className="mt-16 pt-10 border-t border-sk-border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div>
              <p className="text-sk-muted text-sm">Interested in working with us?</p>
              <p className="text-sk-muted text-sm">
                Reach out to discuss a project or collaboration.
              </p>
            </div>
            <Link href="/contact" className="btn-primary shrink-0">
              Contact Us <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </article>
    </>
  );
}
