import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Briefcase, GraduationCap, FlaskConical, Mail } from "lucide-react";

export const metadata: Metadata = {
  title: "Careers",
  description:
    "Career opportunities at STAR-KIN LABS — engineering positions, research collaborations and internships in AI, robotics and automation.",
};

const openingTypes = [
  {
    icon: Briefcase,
    title: "Engineering Positions",
    desc: "Full-time and part-time roles for engineers in embedded systems, robotics, AI and automation.",
  },
  {
    icon: GraduationCap,
    title: "Internships",
    desc: "Hands-on engineering internships for students and fresh graduates looking for real project exposure.",
  },
  {
    icon: FlaskConical,
    title: "Research Collaborations",
    desc: "Joint research partnerships with academic institutions and independent researchers.",
  },
];

export default function CareersPage() {
  return (
    <>
      <section className="pt-32 pb-16 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(26,111,255,0.12)_0%,transparent_60%)]" />
        <div className="absolute inset-0 bg-grid opacity-50" />
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center relative z-10">
          <span className="section-label block mb-4">Join the Team</span>
          <h1 className="heading-xl text-sk-white mb-5">Careers</h1>
          <p className="text-sk-muted text-xl max-w-2xl mx-auto leading-relaxed">
            Work on real engineering problems at the intersection of AI,
            robotics and embedded systems.
          </p>
        </div>
      </section>

      {/* Opportunity types */}
      <section className="pb-16">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-6 mb-16">
            {openingTypes.map((type) => (
              <div
                key={type.title}
                className="bg-sk-card border border-sk-border rounded-xl p-6"
              >
                <div className="w-12 h-12 rounded-lg bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center mb-4">
                  <type.icon size={22} className="text-sk-blue" />
                </div>
                <h3 className="font-display font-600 text-sk-white text-lg mb-3">
                  {type.title}
                </h3>
                <p className="text-sk-muted text-sm leading-relaxed">
                  {type.desc}
                </p>
              </div>
            ))}
          </div>

          {/* Current openings */}
          <div className="bg-sk-card border border-sk-border rounded-2xl p-10 text-center">
            <div className="w-16 h-16 rounded-full bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center mx-auto mb-6">
              <Briefcase size={28} className="text-sk-blue/60" />
            </div>
            <h2 className="font-display font-700 text-2xl text-sk-white mb-3">
              No Current Openings
            </h2>
            <p className="text-sk-muted text-lg max-w-lg mx-auto mb-3">
              We do not have any active positions at this time.
            </p>
            <p className="text-sk-muted text-sm max-w-md mx-auto mb-8">
              We are a growing company and expect to announce opportunities as
              we take on new projects. If you are passionate about real-world
              engineering in AI, robotics or automation — we would still like to
              hear from you.
            </p>

            <a
              href="mailto:starkinlabs.official@gmail.com?subject=Career%20Enquiry%20%E2%80%94%20STAR-KIN%20LABS"
              className="btn-primary inline-flex"
            >
              <Mail size={16} />
              Send Your Profile
            </a>
          </div>

          {/* What we look for */}
          <div className="mt-16">
            <h2 className="heading-md text-sk-white mb-8 text-center">
              What We Look For
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {[
                {
                  title: "Hands-on Orientation",
                  desc: "We value engineers who build things, not just design them. Practical experience — even in personal projects — matters as much as formal credentials.",
                },
                {
                  title: "Real-World Thinking",
                  desc: "Systems must work in real environments with real constraints. We look for engineers who think beyond the lab about power, heat, connectivity and maintainability.",
                },
                {
                  title: "Ownership Mindset",
                  desc: "Every team member at STAR-KIN LABS works with a high degree of ownership. We expect initiative, accountability and the confidence to make decisions.",
                },
                {
                  title: "Learning Drive",
                  desc: "Our work spans AI, embedded systems, robotics and security. The right candidate is someone who actively pursues knowledge across these domains.",
                },
              ].map((item) => (
                <div
                  key={item.title}
                  className="bg-sk-card border border-sk-border rounded-xl p-6"
                >
                  <h3 className="font-display font-600 text-sk-white mb-3">
                    {item.title}
                  </h3>
                  <p className="text-sk-muted text-sm leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Research collaborations */}
          <div className="mt-16 bg-gradient-to-br from-sk-card to-sk-dark border border-sk-blue/20 rounded-2xl p-8">
            <h2 className="font-display font-700 text-xl text-sk-white mb-4">
              Research Collaborations
            </h2>
            <p className="text-sk-muted leading-relaxed mb-6">
              We actively collaborate with academic institutions, research
              scholars and independent researchers on projects in AI, robotics,
              embedded systems and automation. If you are working on research
              that requires engineering prototyping, system integration or field
              testing capability — let us discuss how we might work together.
            </p>
            <Link href="/contact" className="btn-outline text-sm py-2">
              Discuss a Collaboration <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
