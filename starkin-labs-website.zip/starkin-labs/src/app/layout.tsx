import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export const metadata: Metadata = {
  title: {
    default: "STAR-KIN LABS — Building Intelligent Environments",
    template: "%s | STAR-KIN LABS",
  },
  description:
    "STAR-KIN LABS develops AI-powered automation, robotics, cyber security, embedded systems and intelligent environment solutions designed for real-world deployment.",
  keywords: [
    "AI systems",
    "robotics",
    "automation",
    "cyber security",
    "embedded systems",
    "IoT",
    "smart home",
    "intelligent environments",
    "Punjab",
    "India",
    "STAR-KIN LABS",
  ],
  authors: [{ name: "STAR-KIN LABS (OPC) PRIVATE LIMITED" }],
  creator: "STAR-KIN LABS (OPC) PRIVATE LIMITED",
  publisher: "STAR-KIN LABS (OPC) PRIVATE LIMITED",
  metadataBase: new URL("https://starkinlabs.com"),
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: "https://starkinlabs.com",
    siteName: "STAR-KIN LABS",
    title: "STAR-KIN LABS — Building Intelligent Environments",
    description:
      "AI-powered automation, robotics, cyber security, embedded systems and intelligent environment solutions for real-world deployment.",
    images: [
      {
        url: "/assets/logo/starkin-logo.png",
        width: 1200,
        height: 630,
        alt: "STAR-KIN LABS",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "STAR-KIN LABS — Building Intelligent Environments",
    description:
      "AI-powered automation, robotics, cyber security and intelligent environment solutions.",
    images: ["/assets/logo/starkin-logo.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true },
  },
  icons: {
    icon: "/assets/logo/starkin-logo.png",
    apple: "/assets/logo/starkin-logo.png",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-sk-black text-sk-white font-body antialiased">
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
