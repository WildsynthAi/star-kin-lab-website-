import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Tag } from "lucide-react";

export const metadata: Metadata = {
  title: "Blog",
  description:
    "Technical insights, research notes and engineering articles from STAR-KIN LABS on AI, robotics, automation, cyber security and embedded systems.",
};

const categories = [
  "All",
  "Automation",
  "AI",
  "Cyber Security",
  "Robotics",
  "Research",
  "Industry Insights",
];

const posts = [
  {
    slug: "building-edge-ai-for-indian-factories",
    category: "AI",
    date: "2026",
    title: "Building Edge AI for Indian Factories",
    excerpt:
      "Why deploying AI at the edge — without cloud dependency — is the right approach for manufacturing environments in India. A technical and practical perspective.",
    readTime: "8 min read",
    img: "/assets/blog/edge-ai-factories.jpg",
  },
  {
    slug: "embedded-security-in-iot-systems",
    category: "Cyber Security",
    date: "2026",
    title: "Embedded Security in IoT Systems",
    excerpt:
      "Security cannot be an afterthought in IoT devices. How we approach threat modelling and secure boot design from the earliest schematic stage.",
    readTime: "6 min read",
    img: "/assets/blog/embedded-security.jpg",
  },
  {
    slug: "robotics-in-small-workshops",
    category: "Robotics",
    date: "2026",
    title: "Robotics in Small Workshops",
    excerpt:
      "Industrial robots are not just for large factories. Practical robotic integration for small and medium-scale workshops — what works, what doesn't.",
    readTime: "7 min read",
    img: "/assets/blog/workshop-robotics.jpg",
  },
  {
    slug: "freertos-for-industrial-embedded",
    category: "Research",
    date: "2026",
    title: "FreeRTOS for Industrial Embedded Systems",
    excerpt:
      "A technical guide to task scheduling, inter-task communication and watchdog management in FreeRTOS-based industrial controllers.",
    readTime: "12 min read",
    img: "/assets/blog/freertos.jpg",
  },
  {
    slug: "india-automation-gap",
    category: "Industry Insights",
    date: "2026",
    title: "The India Automation Gap",
    excerpt:
      "India's manufacturing sector is underautomated not because of lack of demand, but because solutions have not been designed for Indian operating realities.",
    readTime: "5 min read",
    img: "/assets/blog/india-automation.jpg",
  },
  {
    slug: "smart-sensor-fusion",
    category: "Research",
    date: "2026",
    title: "Sensor Fusion for Machine Health Monitoring",
    excerpt:
      "Combining vibration, temperature and current signatures to build more accurate anomaly detection models for rotating machinery.",
    readTime: "10 min read",
    img: "/assets/blog/sensor-fusion.jpg",
  },
];

const catColors: Record<string, string> = {
  AI: "text-blue-400",
  "Cyber Security": "text-red-400",
  Robotics: "text-emerald-400",
  Research: "text-purple-400",
  "Industry Insights": "text-amber-400",
  Automation: "text-cyan-400",
};

export default function BlogPage() {
  return (
    <>
      <section className="pt-32 pb-16 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(26,111,255,0.12)_0%,transparent_60%)]" />
        <div className="absolute inset-0 bg-grid opacity-50" />
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center relative z-10">
          <span className="section-label block mb-4">Engineering Insights</span>
          <h1 className="heading-xl text-sk-white mb-5">From the Lab</h1>
          <p className="text-sk-muted text-xl max-w-2xl mx-auto">
            Technical articles, research notes and industry perspectives from
            the STAR-KIN LABS engineering team.
          </p>
        </div>
      </section>

      {/* Categories */}
      <section className="pb-8 border-b border-sk-border sticky top-16 lg:top-20 bg-sk-black/90 backdrop-blur-md z-30">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center gap-3 overflow-x-auto py-4 scrollbar-hide">
            {categories.map((cat) => (
              <button
                key={cat}
                className={`shrink-0 px-4 py-2 rounded-lg text-sm font-display font-500 tracking-wide transition-colors ${
                  cat === "All"
                    ? "bg-sk-blue text-white"
                    : "bg-sk-card border border-sk-border text-sk-muted hover:border-sk-blue/30 hover:text-sk-white"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Posts grid */}
      <section className="py-16 pb-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <Link
                key={post.slug}
                href={`/blog/${post.slug}`}
                className="group block bg-sk-card border border-sk-border rounded-xl overflow-hidden hover:border-sk-blue/30 hover:-translate-y-1 transition-all duration-300"
              >
                {/* Image */}
                <div className="aspect-video bg-gradient-to-br from-sk-dark to-sk-card relative overflow-hidden">
                  {/* Replace with: <Image src={post.img} alt={post.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" /> */}
                  <div className="absolute inset-0 bg-grid opacity-20" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="font-mono text-[9px] text-sk-border px-2 text-center">
                      {post.img.split("/").pop()}
                    </span>
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-display font-500 ${catColors[post.category] || "text-sk-blue"}`}
                    >
                      <Tag size={10} />
                      {post.category}
                    </span>
                    <span className="text-sk-border text-xs">·</span>
                    <span className="font-mono text-xs text-sk-border">
                      {post.readTime}
                    </span>
                  </div>

                  <h2 className="font-display font-600 text-sk-white text-lg mb-3 group-hover:text-sk-blue transition-colors leading-snug">
                    {post.title}
                  </h2>

                  <p className="text-sk-muted text-sm leading-relaxed">
                    {post.excerpt}
                  </p>

                  <div className="mt-4 pt-4 border-t border-sk-border flex items-center justify-between">
                    <span className="font-mono text-xs text-sk-border">
                      {post.date}
                    </span>
                    <span className="inline-flex items-center gap-1 text-sk-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                      Read <ArrowRight size={11} />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
