import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ArrowRight, Tag } from "lucide-react";

// Sample post data — in production, replace with CMS/MDX fetch
const posts: Record<string, {
  title: string;
  category: string;
  date: string;
  readTime: string;
  excerpt: string;
  content: string[];
}> = {
  "building-edge-ai-for-indian-factories": {
    title: "Building Edge AI for Indian Factories",
    category: "AI",
    date: "2026",
    readTime: "8 min read",
    excerpt: "Why deploying AI at the edge — without cloud dependency — is the right approach for manufacturing environments in India.",
    content: [
      "India's manufacturing sector is undergoing a quiet transformation. Across small and mid-scale factories in Punjab, Gujarat, Tamil Nadu and Maharashtra, engineers are beginning to ask a question that would have seemed impractical five years ago: can we run machine intelligence locally, without a cloud subscription?",
      "The answer, increasingly, is yes. And for Indian factory environments specifically, it is not just possible — it is the right architecture.",
      "Cloud-connected AI systems come with a set of assumptions that do not hold in many Indian industrial settings. Reliable, low-latency internet connectivity is assumed. A stable power supply for network equipment is assumed. A security posture that is comfortable with production data leaving the facility is assumed. In many factories across India, none of these assumptions are valid.",
      "Edge AI — inference running on hardware physically present in the facility — sidesteps all of these constraints. The model runs on a local compute board. Decisions are made in milliseconds without a network round trip. Production data never leaves the floor. And when the internet goes down, the system keeps working.",
      "The hardware story has changed dramatically. NVIDIA Jetson modules bring GPU-accelerated inference to devices that consume under 20W and cost under ₹20,000. Microcontrollers like the STM32H7 series can run quantised neural networks directly on-chip. Raspberry Pi 5 handles real-time object detection at 10+ frames per second.",
      "The software toolchain has matured in parallel. TensorFlow Lite, ONNX Runtime and OpenVINO all support deployment to low-power hardware. Model quantisation — reducing 32-bit floating point weights to 8-bit integers — cuts memory requirements and inference latency by 4x with minimal accuracy loss on well-trained models.",
      "At STAR-KIN LABS, we have deployed edge AI for defect detection, security monitoring and machine health classification across prototype and pilot installations. The architecture is consistent: a compact compute module mounted close to the machine or camera, running a quantised model trained on data from that specific environment, communicating to a local dashboard over the facility network.",
      "The training pipeline is cloud-based — we use GPU infrastructure for model training and validation. But once trained and quantised, the model is deployed locally and runs indefinitely without any external dependency.",
      "This is the right model for Indian factories. Not because cloud AI is technically inferior — it is not — but because the practical realities of operating environments in India make local inference the more reliable, more secure and more maintainable choice.",
    ],
  },
  "embedded-security-in-iot-systems": {
    title: "Embedded Security in IoT Systems",
    category: "Cyber Security",
    date: "2026",
    readTime: "6 min read",
    excerpt: "Security cannot be an afterthought in IoT devices. How we approach threat modelling and secure boot design from the earliest schematic stage.",
    content: [
      "The IoT security problem is not new. For years, security researchers have documented how connected devices ship with default credentials, unencrypted communications and firmware that cannot be updated. The consequences — from botnets to industrial sabotage — are well documented.",
      "What is less discussed is how to actually build security into an IoT device from the beginning. Security retrofitted onto an existing design is expensive, incomplete and often ineffective. Security designed in from the schematic stage is practical, cost-effective and genuinely robust.",
      "Our security design process starts with threat modelling before any hardware selection is made. Who might attack this device? What are they trying to achieve? What is the impact of a successful attack? For an industrial sensor node, the threat model is different from a consumer smart plug. A factory environment sensor might be targeted to feed false readings into a control system. A smart access controller might be targeted to gain physical entry. The attack surface and mitigation strategies differ accordingly.",
      "At the hardware level, our baseline for any IoT device includes: a secure element or hardware security module for key storage, hardware-enforced secure boot from an immutable root of trust, tamper detection where physical access is a risk, and JTAG/debug interface disabled in production builds.",
      "At the firmware level: all external communication encrypted with TLS 1.3 or DTLS for constrained devices, certificate-based device authentication, signed OTA firmware updates with rollback protection, and minimal attack surface — no unnecessary services, no default credentials.",
      "At the network level: devices communicate only on required ports and protocols, outbound connections only unless inbound is strictly necessary, and network segmentation to isolate device traffic from broader infrastructure.",
      "This is not theoretical. Every IoT product we build at STAR-KIN LABS goes through this process. It adds time at the design stage — typically two to four weeks for a new hardware platform. But it eliminates the far larger cost of security incidents, recall-level firmware updates and reputational damage from vulnerable products.",
      "Build it secure the first time. The alternative is paying for it repeatedly, on someone else's timeline.",
    ],
  },
};

export async function generateStaticParams() {
  return Object.keys(posts).map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const post = posts[params.slug];
  if (!post) return { title: "Post Not Found" };
  return {
    title: post.title,
    description: post.excerpt,
  };
}

export default function BlogPostPage({
  params,
}: {
  params: { slug: string };
}) {
  const post = posts[params.slug];

  if (!post) {
    return (
      <section className="min-h-screen flex items-center justify-center">
        <div className="text-center px-6">
          <h1 className="font-display font-700 text-3xl text-sk-white mb-4">
            Post Not Found
          </h1>
          <Link href="/blog" className="btn-primary inline-flex">
            <ArrowLeft size={16} /> Back to Blog
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <section className="pt-32 pb-12 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_40%_at_50%_0%,rgba(26,111,255,0.1)_0%,transparent_60%)]" />
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="max-w-3xl mx-auto px-6 lg:px-8 relative z-10">
          <Link
            href="/blog"
            className="inline-flex items-center gap-2 text-sk-muted text-sm mb-8 hover:text-sk-white transition-colors"
          >
            <ArrowLeft size={14} /> Back to Blog
          </Link>

          <div className="flex items-center gap-3 mb-5">
            <span className="inline-flex items-center gap-1 text-sm font-display font-500 text-sk-blue">
              <Tag size={12} />
              {post.category}
            </span>
            <span className="text-sk-border">·</span>
            <span className="font-mono text-xs text-sk-muted">{post.readTime}</span>
            <span className="text-sk-border">·</span>
            <span className="font-mono text-xs text-sk-muted">{post.date}</span>
          </div>

          <h1 className="heading-xl text-sk-white mb-5">{post.title}</h1>
          <p className="text-sk-muted text-xl leading-relaxed">{post.excerpt}</p>

          <div className="mt-8 pt-8 border-t border-sk-border flex items-center gap-4">
            <div className="w-9 h-9 rounded-full bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center">
              <span className="font-mono text-xs text-sk-blue">SS</span>
            </div>
            <div>
              <div className="font-display font-600 text-sk-white text-sm">Sandeep Singh</div>
              <div className="text-sk-muted text-xs">Founder & Director, STAR-KIN LABS</div>
            </div>
          </div>
        </div>
      </section>

      {/* Hero image placeholder */}
      <div className="max-w-3xl mx-auto px-6 lg:px-8 mb-12">
        <div className="aspect-video rounded-xl bg-gradient-to-br from-sk-dark to-sk-card border border-sk-border relative overflow-hidden">
          <div className="absolute inset-0 bg-grid opacity-20" />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="font-mono text-xs text-sk-border">
              /assets/blog/{params.slug}.jpg
            </span>
          </div>
        </div>
      </div>

      {/* Article body */}
      <article className="pb-24">
        <div className="max-w-3xl mx-auto px-6 lg:px-8">
          <div className="space-y-6">
            {post.content.map((para, i) => (
              <p key={i} className="text-sk-muted leading-relaxed text-lg">
                {para}
              </p>
            ))}
          </div>

          <div className="mt-16 pt-10 border-t border-sk-border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <Link
              href="/blog"
              className="inline-flex items-center gap-2 text-sk-muted hover:text-sk-white transition-colors"
            >
              <ArrowLeft size={14} /> All Articles
            </Link>
            <Link href="/contact" className="btn-primary">
              Discuss a Project <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </article>
    </>
  );
}
