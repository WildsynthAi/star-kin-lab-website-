import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "Privacy Policy for STAR-KIN LABS (OPC) PRIVATE LIMITED.",
};

export default function PrivacyPage() {
  return (
    <>
      <section className="pt-32 pb-12 relative">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="max-w-3xl mx-auto px-6 lg:px-8 relative z-10">
          <span className="section-label block mb-4">Legal</span>
          <h1 className="heading-xl text-sk-white mb-4">Privacy Policy</h1>
          <p className="text-sk-muted">
            Last updated: 2026 — STAR-KIN LABS (OPC) PRIVATE LIMITED
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 space-y-10 text-sk-muted leading-relaxed">
          {[
            {
              title: "1. Information We Collect",
              body: "We collect information you voluntarily provide when contacting us through our website — including your name, email address, phone number and the content of your message. We do not collect personal data through tracking cookies or third-party analytics without your consent.",
            },
            {
              title: "2. How We Use Your Information",
              body: "Information you provide is used solely to respond to your enquiry, fulfil a service engagement or communicate relevant updates. We do not sell, trade or rent your personal information to third parties.",
            },
            {
              title: "3. Data Storage and Security",
              body: "We take reasonable technical and organisational measures to protect personal information from unauthorised access, loss or disclosure. Contact form submissions are stored securely and accessed only by authorised team members.",
            },
            {
              title: "4. Cookies",
              body: "Our website uses only essential cookies required for basic functionality. We do not use advertising or tracking cookies. You may disable cookies in your browser settings without affecting your ability to use our site.",
            },
            {
              title: "5. Third-Party Links",
              body: "Our website may contain links to external sites. We are not responsible for the privacy practices or content of those sites and encourage you to review their privacy policies independently.",
            },
            {
              title: "6. Your Rights",
              body: "You have the right to request access to, correction of, or deletion of personal information we hold about you. To make such a request, contact us at starkinlabs.official@gmail.com.",
            },
            {
              title: "7. Contact",
              body: "For any privacy-related queries, contact STAR-KIN LABS (OPC) PRIVATE LIMITED at: starkinlabs.official@gmail.com | Annia Road, Amloh, Fatehgarh Sahib, Punjab, India — 147203.",
            },
          ].map((section) => (
            <div key={section.title}>
              <h2 className="font-display font-600 text-xl text-sk-white mb-3">
                {section.title}
              </h2>
              <p>{section.body}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
