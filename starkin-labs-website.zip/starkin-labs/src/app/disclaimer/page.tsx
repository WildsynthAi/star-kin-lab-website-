import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Disclaimer",
  description: "Disclaimer for starkinlabs.com — STAR-KIN LABS (OPC) PRIVATE LIMITED.",
};

export default function DisclaimerPage() {
  return (
    <>
      <section className="pt-32 pb-12 relative">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="max-w-3xl mx-auto px-6 lg:px-8 relative z-10">
          <span className="section-label block mb-4">Legal</span>
          <h1 className="heading-xl text-sk-white mb-4">Disclaimer</h1>
          <p className="text-sk-muted">
            STAR-KIN LABS (OPC) PRIVATE LIMITED — starkinlabs.com
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 space-y-10 text-sk-muted leading-relaxed">
          {[
            {
              title: "General Disclaimer",
              body: "The information provided on starkinlabs.com is for general informational purposes only. While we endeavour to keep content accurate and current, we make no representations or warranties of any kind — express or implied — about the completeness, accuracy or suitability of the information.",
            },
            {
              title: "Technical Content",
              body: "Technical articles, blog posts and research notes published on this website represent the views and findings of our engineering team at the time of writing. They should not be relied upon as authoritative technical specifications without independent verification.",
            },
            {
              title: "Project Information",
              body: "Project descriptions and case studies on this website describe systems in various stages of development and deployment. Specifications, outcomes and capabilities described are specific to each project context and may not be representative of results achievable in other environments.",
            },
            {
              title: "External Links",
              body: "Links to third-party websites are provided for convenience only. STAR-KIN LABS (OPC) PRIVATE LIMITED does not endorse the content of those sites and accepts no responsibility for them.",
            },
            {
              title: "No Professional Advice",
              body: "Nothing on this website constitutes professional engineering, legal or financial advice. Engage qualified professionals for any specific project, legal or financial requirements.",
            },
          ].map((section) => (
            <div key={section.title}>
              <h2 className="font-display font-600 text-xl text-sk-white mb-3">
                {section.title}
              </h2>
              <p>{section.body}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
