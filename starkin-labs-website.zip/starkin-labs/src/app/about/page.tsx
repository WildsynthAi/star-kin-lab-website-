import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, User, Target, Eye, Zap } from "lucide-react";

export const metadata: Metadata = {
  title: "About",
  description:
    "Learn about STAR-KIN LABS — our story, mission, vision and the team behind our AI and automation engineering work.",
};

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="pt-32 pb-20 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(26,111,255,0.12)_0%,transparent_60%)]" />
        <div className="absolute inset-0 bg-grid opacity-50" />
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center relative z-10">
          <span className="section-label block mb-4">Our Story</span>
          <h1 className="heading-xl text-sk-white mb-5">
            About STAR-KIN LABS
          </h1>
          <p className="text-sk-muted text-xl max-w-2xl mx-auto leading-relaxed">
            An engineering company built to bridge advanced technology and
            practical, real-world deployment.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div>
              <h2 className="heading-md text-sk-white mb-6">
                How We Started
              </h2>
              <p className="text-sk-muted leading-relaxed mb-5">
                STAR-KIN LABS (OPC) PRIVATE LIMITED was incorporated in 2026
                with a straightforward ambition: to build technology that
                actually works in the real world. Not just in controlled lab
                conditions — but in factories, workshops, schools and homes
                across India.
              </p>
              <p className="text-sk-muted leading-relaxed mb-5">
                The company emerged from hands-on engineering experience in
                automation, robotics and embedded systems — and a clear
                observation that most technology implementations fail not
                because the underlying technology is wrong, but because it was
                never designed for the environment it would operate in.
              </p>
              <p className="text-sk-muted leading-relaxed">
                STAR-KIN LABS focuses on the full stack: from hardware
                schematics and firmware to software interfaces and field
                deployment. Every system we build is designed to be
                maintained, upgraded and understood by the people who operate
                it.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {[
                {
                  icon: Target,
                  title: "Mission",
                  desc: "Build intelligent environments that improve efficiency, security and usability for everyday users — in real operational conditions.",
                },
                {
                  icon: Eye,
                  title: "Vision",
                  desc: "Create technology systems that normal people can use confidently, without requiring specialist knowledge or external support dependency.",
                },
                {
                  icon: Zap,
                  title: "Approach",
                  desc: "Hands-on engineering from concept to deployment. We design, build, test and install — and we stand behind everything we deliver.",
                },
              ].map((item) => (
                <div
                  key={item.title}
                  className="bg-sk-card border border-sk-border rounded-xl p-6"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-9 h-9 rounded-lg bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center">
                      <item.icon size={16} className="text-sk-blue" />
                    </div>
                    <span className="font-display font-600 text-sk-white">
                      {item.title}
                    </span>
                  </div>
                  <p className="text-sk-muted text-sm leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Focus areas */}
      <section className="py-20 bg-sk-dark/40 border-y border-sk-border">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="heading-md text-sk-white">Technical Focus Areas</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {[
              "Artificial Intelligence",
              "Robotics",
              "Automation Systems",
              "Cyber Security",
              "Embedded Systems",
              "IoT & Connectivity",
              "Smart Environments",
              "Prototype Development",
              "Industrial Monitoring",
              "Custom R&D",
            ].map((area) => (
              <div
                key={area}
                className="bg-sk-card border border-sk-border rounded-lg px-4 py-3 text-center"
              >
                <span className="font-display text-sm text-sk-white">
                  {area}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Founder */}
      <section id="founder" className="py-20">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="section-label block mb-3">Leadership</span>
            <h2 className="heading-md text-sk-white">Founder & Director</h2>
          </div>

          <div className="bg-sk-card border border-sk-border rounded-2xl overflow-hidden">
            <div className="grid md:grid-cols-3">
              {/* Photo */}
              <div className="aspect-square md:aspect-auto bg-gradient-to-br from-sk-dark to-sk-card relative overflow-hidden">
                {/*
                  Replace with:
                  <Image src="/assets/founder/founder.jpg" alt="Sandeep Singh" fill className="object-cover object-center" />
                */}
                <div className="absolute inset-0 bg-grid opacity-20" />
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-sk-blue/10 border-2 border-sk-blue/20 flex items-center justify-center mb-3">
                    <User size={36} className="text-sk-blue/50" />
                  </div>
                  <span className="font-mono text-[10px] text-sk-border">
                    /assets/founder/founder.jpg
                  </span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 h-1/4 bg-gradient-to-t from-sk-card to-transparent md:hidden" />
              </div>

              {/* Content */}
              <div className="md:col-span-2 p-8 lg:p-12">
                <div className="mb-6">
                  <h3 className="font-display font-700 text-3xl text-sk-white mb-1">
                    Sandeep Singh
                  </h3>
                  <p className="text-sk-blue font-display text-base tracking-wide">
                    Founder & Director, STAR-KIN LABS
                  </p>
                </div>

                <p className="text-sk-muted leading-relaxed mb-5">
                  With a hands-on engineering background spanning automation,
                  intelligent systems and embedded development, Sandeep Singh
                  founded STAR-KIN LABS to solve a problem he observed
                  directly: the gap between what technology can do and what
                  gets actually deployed and used.
                </p>

                <p className="text-sk-muted leading-relaxed mb-5">
                  His approach to engineering is practical and
                  environment-first. Every project begins with understanding
                  the real operating context — the physical environment, the
                  operators, the power infrastructure and the maintenance
                  reality — before any design decisions are made.
                </p>

                <p className="text-sk-muted leading-relaxed mb-8">
                  Under his direction, STAR-KIN LABS focuses on building
                  systems that are reliable, maintainable and genuinely useful
                  to the people and organisations that operate them.
                </p>

                <div className="flex flex-wrap gap-2">
                  {[
                    "Automation Engineering",
                    "Robotics",
                    "AI Systems",
                    "Embedded Development",
                    "System Architecture",
                  ].map((tag) => (
                    <span key={tag} className="sk-tag">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Company details */}
      <section className="py-16 border-t border-sk-border">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="heading-md text-sk-white">Company Information</h2>
          </div>
          <div className="bg-sk-card border border-sk-border rounded-xl p-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div>
                  <span className="font-mono text-[10px] text-sk-blue tracking-widest uppercase block mb-1">
                    Registered Name
                  </span>
                  <p className="font-display font-600 text-sk-white">
                    STAR-KIN LABS (OPC) PRIVATE LIMITED
                  </p>
                </div>
                <div>
                  <span className="font-mono text-[10px] text-sk-blue tracking-widest uppercase block mb-1">
                    CIN
                  </span>
                  <p className="font-mono text-sm text-sk-muted">
                    U58201PB2026OPC068447
                  </p>
                </div>
                <div>
                  <span className="font-mono text-[10px] text-sk-blue tracking-widest uppercase block mb-1">
                    GSTIN
                  </span>
                  <p className="font-mono text-sm text-sk-muted">
                    03ABTCS8388J1ZF
                  </p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <span className="font-mono text-[10px] text-sk-blue tracking-widest uppercase block mb-1">
                    Registered Address
                  </span>
                  <p className="text-sk-muted text-sm leading-relaxed">
                    Annia Road, Amloh
                    <br />
                    Fatehgarh Sahib, Punjab
                    <br />
                    India — 147203
                  </p>
                </div>
                <div>
                  <span className="font-mono text-[10px] text-sk-blue tracking-widest uppercase block mb-1">
                    Type
                  </span>
                  <p className="text-sk-muted text-sm">
                    One Person Company (OPC) — Private Limited
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 border-t border-sk-border">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <Link href="/contact" className="btn-primary">
            Work with Us <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
