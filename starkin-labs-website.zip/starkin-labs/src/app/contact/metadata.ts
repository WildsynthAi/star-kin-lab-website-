import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Contact STAR-KIN LABS — reach our team for project enquiries, service information or general questions.",
};

export { default } from "./ContactPage";
