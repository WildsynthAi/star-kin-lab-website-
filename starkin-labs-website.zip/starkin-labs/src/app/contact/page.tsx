"use client";

import { useState } from "react";
import { Mail, Phone, MapPin, Globe, Send, CheckCircle2 } from "lucide-react";

export default function ContactPage() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Connect to your form backend / Netlify Forms / Formspree here
    setSent(true);
  };

  return (
    <>
      <section className="pt-32 pb-16 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(26,111,255,0.12)_0%,transparent_60%)]" />
        <div className="absolute inset-0 bg-grid opacity-50" />
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center relative z-10">
          <span className="section-label block mb-4">Reach Out</span>
          <h1 className="heading-xl text-sk-white mb-5">Contact Us</h1>
          <p className="text-sk-muted text-xl max-w-2xl mx-auto">
            Tell us about your project, enquire about our services or reach
            out with any questions.
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Contact form */}
            <div className="lg:col-span-3">
              {sent ? (
                <div className="bg-sk-card border border-emerald-500/30 rounded-2xl p-12 text-center">
                  <CheckCircle2 size={48} className="text-emerald-400 mx-auto mb-4" />
                  <h2 className="font-display font-700 text-2xl text-sk-white mb-3">
                    Message Sent
                  </h2>
                  <p className="text-sk-muted">
                    Thank you for reaching out. We will get back to you
                    shortly.
                  </p>
                </div>
              ) : (
                <form
                  onSubmit={handleSubmit}
                  className="bg-sk-card border border-sk-border rounded-2xl p-8 space-y-5"
                  // For Netlify Forms, add: data-netlify="true" name="contact"
                >
                  <h2 className="font-display font-700 text-xl text-sk-white mb-6">
                    Send a Message
                  </h2>

                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block font-display text-sm text-sk-muted mb-2">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        className="sk-input"
                        placeholder="Your name"
                        value={form.name}
                        onChange={(e) =>
                          setForm({ ...form, name: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <label className="block font-display text-sm text-sk-muted mb-2">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        className="sk-input"
                        placeholder="your@email.com"
                        value={form.email}
                        onChange={(e) =>
                          setForm({ ...form, email: e.target.value })
                        }
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block font-display text-sm text-sk-muted mb-2">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        className="sk-input"
                        placeholder="+91 XXXXX XXXXX"
                        value={form.phone}
                        onChange={(e) =>
                          setForm({ ...form, phone: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <label className="block font-display text-sm text-sk-muted mb-2">
                        Company / Organisation
                      </label>
                      <input
                        type="text"
                        className="sk-input"
                        placeholder="Optional"
                        value={form.company}
                        onChange={(e) =>
                          setForm({ ...form, company: e.target.value })
                        }
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-display text-sm text-sk-muted mb-2">
                      Message *
                    </label>
                    <textarea
                      required
                      className="sk-input"
                      placeholder="Describe your project, requirement or enquiry..."
                      value={form.message}
                      onChange={(e) =>
                        setForm({ ...form, message: e.target.value })
                      }
                    />
                  </div>

                  <button type="submit" className="btn-primary w-full justify-center">
                    <Send size={15} />
                    Send Message
                  </button>
                  <p className="text-sk-muted text-xs text-center">
                    We typically respond within 1–2 business days.
                  </p>
                </form>
              )}
            </div>

            {/* Contact details */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h2 className="font-display font-700 text-xl text-sk-white mb-6">
                  Contact Information
                </h2>
                <div className="space-y-4">
                  {[
                    {
                      icon: Mail,
                      label: "Email",
                      value: "starkinlabs.official@gmail.com",
                      href: "mailto:starkinlabs.official@gmail.com",
                    },
                    {
                      icon: Phone,
                      label: "Phone",
                      value: "+91 62843 58633",
                      href: "tel:+916284358633",
                    },
                    {
                      icon: Globe,
                      label: "Website",
                      value: "starkinlabs.com",
                      href: "https://starkinlabs.com",
                    },
                  ].map((item) => (
                    <a
                      key={item.label}
                      href={item.href}
                      className="flex items-center gap-4 p-4 bg-sk-card border border-sk-border rounded-xl hover:border-sk-blue/30 transition-colors group"
                    >
                      <div className="w-10 h-10 rounded-lg bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center shrink-0">
                        <item.icon size={16} className="text-sk-blue" />
                      </div>
                      <div>
                        <div className="font-mono text-[10px] text-sk-blue tracking-widest uppercase">
                          {item.label}
                        </div>
                        <div className="text-sk-white text-sm group-hover:text-sk-blue-light transition-colors">
                          {item.value}
                        </div>
                      </div>
                    </a>
                  ))}
                </div>
              </div>

              {/* Address */}
              <div className="p-4 bg-sk-card border border-sk-border rounded-xl">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-sk-blue/10 border border-sk-blue/20 flex items-center justify-center shrink-0">
                    <MapPin size={16} className="text-sk-blue" />
                  </div>
                  <div>
                    <div className="font-mono text-[10px] text-sk-blue tracking-widest uppercase mb-2">
                      Registered Address
                    </div>
                    <p className="text-sk-white text-sm leading-relaxed">
                      STAR-KIN LABS (OPC) PRIVATE LIMITED
                      <br />
                      Annia Road, Amloh
                      <br />
                      Fatehgarh Sahib, Punjab
                      <br />
                      India — 147203
                    </p>
                  </div>
                </div>
              </div>

              {/* Map placeholder */}
              <div className="rounded-xl border border-sk-border overflow-hidden aspect-video bg-gradient-to-br from-sk-dark to-sk-card relative">
                {/*
                  Replace with Google Maps embed:
                  <iframe
                    src="https://www.google.com/maps/embed?pb=..."
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                  />
                */}
                <div className="absolute inset-0 bg-grid opacity-20" />
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
                  <MapPin size={32} className="text-sk-blue/30" />
                  <span className="font-mono text-xs text-sk-border text-center px-4">
                    Google Maps Embed
                    <br />
                    Amloh, Fatehgarh Sahib, Punjab
                  </span>
                </div>
              </div>

              {/* Company reg */}
              <div className="p-4 bg-sk-card border border-sk-border rounded-xl">
                <div className="font-mono text-[10px] text-sk-blue tracking-widest uppercase mb-3">
                  Company Registration
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-sk-muted">CIN</span>
                    <span className="font-mono text-sk-white text-xs">
                      U58201PB2026OPC068447
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-sk-muted">GSTIN</span>
                    <span className="font-mono text-sk-white text-xs">
                      03ABTCS8388J1ZF
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
