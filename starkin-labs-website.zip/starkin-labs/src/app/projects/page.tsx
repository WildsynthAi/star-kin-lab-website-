import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, ExternalLink } from "lucide-react";

export const metadata: Metadata = {
  title: "Projects",
  description:
    "Explore STAR-KIN LABS projects: AI security nodes, robotic workbenches, smart environment controllers and industrial monitoring platforms.",
};

const projects = [
  {
    id: "security-node",
    number: "01",
    title: "Autonomous Security Node",
    category: "AI · Cyber Security",
    status: "Active",
    img: "/assets/projects/security-node.jpg",
    summary:
      "An intelligent edge-deployed security system using computer vision, motion analytics and real-time threat detection — designed for perimeter security without cloud dependency.",
    challenge:
      "Conventional IP cameras produce raw footage requiring constant human monitoring. The challenge was to create a low-cost, low-power node that could make intelligent decisions locally — identifying threats, triggering alerts and logging events without a persistent internet connection.",
    approach:
      "We developed a custom embedded Linux platform running a quantised object detection model. The node communicates over a local mesh network and logs to an encrypted on-device database. Power draw is under 8W in active mode.",
    outcomes: [
      "Real-time object classification at the edge",
      "Alert latency under 200ms",
      "Operates without cloud connectivity",
      "Under 8W power consumption",
    ],
    tags: ["Computer Vision", "Edge AI", "Embedded Linux", "Mesh Network"],
  },
  {
    id: "workbench",
    number: "02",
    title: "Intelligent Robotic Workbench",
    category: "Robotics · Automation",
    status: "Development",
    img: "/assets/projects/robotic-workbench.jpg",
    summary:
      "A semi-autonomous workbench system integrating robotic arms, computer vision and smart tooling management to assist engineers in assembly and testing workflows.",
    challenge:
      "Repetitive assembly tasks in prototype development are time-consuming and error-prone. We needed a system that could assist engineers by automating component placement, orientation correction and basic test execution.",
    approach:
      "A 6-DOF robotic arm with a camera-guided vision system handles component placement. The workbench includes tool presence detection, soldering iron temperature control and an HMI for workflow management.",
    outcomes: [
      "60% reduction in component placement errors",
      "Integrated vision-based orientation correction",
      "Custom HMI for workflow control",
      "Modular tooling attachment system",
    ],
    tags: ["6-DOF Arm", "Computer Vision", "HMI", "Custom Tooling"],
  },
  {
    id: "environment-controller",
    number: "03",
    title: "Smart Environment Controller",
    category: "IoT · Embedded Systems",
    status: "Prototype",
    img: "/assets/projects/environment-controller.jpg",
    summary:
      "A unified controller for building environments — managing climate, lighting, access and energy consumption through a single embedded platform with mobile interface.",
    challenge:
      "Building automation systems are typically fragmented across multiple vendor-specific platforms. The goal was a single unified controller that could manage all environmental systems with a simple, non-technical user interface.",
    approach:
      "Built on a custom RTOS-based embedded platform with multi-protocol support (Modbus, MQTT, KNX). A companion mobile application provides occupant control. The system logs energy data and can optimise schedules automatically.",
    outcomes: [
      "Single platform managing climate, lighting and access",
      "Multi-protocol hardware support",
      "Mobile app with occupant controls",
      "Automated energy optimisation",
    ],
    tags: ["RTOS", "Modbus", "MQTT", "Mobile App", "Energy Monitoring"],
  },
  {
    id: "ai-monitoring",
    number: "04",
    title: "AI Monitoring Platform",
    category: "AI · Industrial",
    status: "Active",
    img: "/assets/projects/ai-monitoring.jpg",
    summary:
      "Real-time machine health monitoring using sensor fusion and ML-based anomaly detection — predicts failures and reduces downtime in industrial environments.",
    challenge:
      "Unplanned equipment failures cause significant downtime in manufacturing. Existing condition monitoring solutions are expensive and require specialist installation. We needed an accessible system any engineering team could deploy.",
    approach:
      "Wireless sensor nodes measure vibration, temperature, current draw and acoustics. Data streams to a local server running an ensemble anomaly detection model trained on normal machine signatures. Alerts are delivered via dashboard and SMS.",
    outcomes: [
      "Anomaly detection accuracy above 94%",
      "Wireless sensor deployment — no wiring changes",
      "Predictive alerts 4–48 hours before failure",
      "Local server — no cloud subscription required",
    ],
    tags: ["Sensor Fusion", "Anomaly Detection", "Wireless Sensors", "Dashboard"],
  },
  {
    id: "automation-dashboard",
    number: "05",
    title: "Industrial Automation Dashboard",
    category: "Automation · SCADA",
    status: "Development",
    img: "/assets/projects/automation-dashboard.jpg",
    summary:
      "A comprehensive SCADA-style control dashboard for industrial automation lines — featuring live process monitoring, remote control and event logging.",
    challenge:
      "Operators managing multiple PLCs and automation controllers lacked a unified view of line status. Existing SCADA solutions required expensive licensing and were difficult to customise for specific production lines.",
    approach:
      "An open-source stack connecting to PLCs via Modbus TCP and OPC-UA. The dashboard presents live process data, control interfaces, alarm management and historical event logs. Deployed on industrial panel PCs.",
    outcomes: [
      "Unified dashboard for all PLC and controller data",
      "Real-time process visualisation",
      "Alarm management with escalation rules",
      "Historical data logging and export",
    ],
    tags: ["SCADA", "Modbus TCP", "OPC-UA", "HMI", "Alarm Management"],
  },
];

const statusColors: Record<string, string> = {
  Active: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  Development: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  Prototype: "bg-sky-500/10 text-sky-400 border-sky-500/20",
};

export default function ProjectsPage() {
  return (
    <>
      <section className="pt-32 pb-16 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_0%,rgba(26,111,255,0.12)_0%,transparent_60%)]" />
        <div className="absolute inset-0 bg-grid opacity-50" />
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center relative z-10">
          <span className="section-label block mb-4">Engineering Work</span>
          <h1 className="heading-xl text-sk-white mb-5">Featured Projects</h1>
          <p className="text-sk-muted text-xl max-w-2xl mx-auto leading-relaxed">
            Systems we are designing, building and deploying to solve real
            engineering problems.
          </p>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-5xl mx-auto px-6 lg:px-8 space-y-20">
          {projects.map((proj) => (
            <div key={proj.id} id={proj.id}>
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-8 pb-8 border-b border-sk-border">
                <span className="font-mono text-4xl font-bold text-sk-border">
                  {proj.number}
                </span>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-3 mb-2">
                    <span className="sk-tag">{proj.category}</span>
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono tracking-widest uppercase border ${statusColors[proj.status]}`}
                    >
                      <span className="w-1 h-1 rounded-full bg-current animate-pulse" />
                      {proj.status}
                    </span>
                  </div>
                  <h2 className="heading-md text-sk-white">{proj.title}</h2>
                </div>
              </div>

              {/* Image */}
              <div className="rounded-xl overflow-hidden border border-sk-border mb-10 aspect-video bg-gradient-to-br from-sk-dark to-sk-card relative">
                {/* Replace with: <Image src={proj.img} alt={proj.title} fill className="object-cover" /> */}
                <div className="absolute inset-0 bg-grid opacity-20" />
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                  <span className="font-display font-bold text-7xl text-sk-border/20">
                    {proj.number}
                  </span>
                  <span className="font-mono text-xs text-sk-border">
                    {proj.img}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="grid md:grid-cols-3 gap-10">
                <div className="md:col-span-2 space-y-8">
                  <div>
                    <h3 className="font-display font-600 text-sk-white mb-3">
                      Overview
                    </h3>
                    <p className="text-sk-muted leading-relaxed">{proj.summary}</p>
                  </div>
                  <div>
                    <h3 className="font-display font-600 text-sk-white mb-3">
                      Challenge
                    </h3>
                    <p className="text-sk-muted leading-relaxed">
                      {proj.challenge}
                    </p>
                  </div>
                  <div>
                    <h3 className="font-display font-600 text-sk-white mb-3">
                      Approach
                    </h3>
                    <p className="text-sk-muted leading-relaxed">{proj.approach}</p>
                  </div>
                </div>

                <div>
                  <div className="bg-sk-card border border-sk-border rounded-xl p-6 mb-6">
                    <h3 className="font-display font-600 text-sk-white mb-4">
                      Outcomes
                    </h3>
                    <ul className="space-y-3">
                      {proj.outcomes.map((o) => (
                        <li key={o} className="flex items-start gap-3">
                          <span className="text-sk-blue mt-1 shrink-0">→</span>
                          <span className="text-sk-muted text-sm">{o}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <div className="font-display font-500 text-sm text-sk-white mb-3">
                      Technologies
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {proj.tags.map((t) => (
                        <span key={t} className="sk-tag text-[10px]">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 border-t border-sk-border">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="heading-md text-sk-white mb-4">
            Have a project in mind?
          </h2>
          <p className="text-sk-muted mb-8">
            We work on custom engineering projects across all our service areas.
          </p>
          <Link href="/contact" className="btn-primary">
            Discuss Your Project <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
